<?php
namespace App\Services;
use App\Core\Database;

/** Netvera editorial metadata on top of the existing service/category/blog schema. */
final class NetveraSeoBridge
{
    private static array $cache = [];

    public static function get(string $type,int $id):array
    {
        if(!in_array($type,['package','category','blog'],true)||$id<1)return [];
        $key=$type.':'.$id;
        if(isset(self::$cache[$key]))return self::$cache[$key];
        try{
            $row=Database::getInstance()->fetch(
                "SELECT extra_json FROM nv_editorial_seo WHERE entity_type=? AND entity_id=?",
                [$type,$id]
            );
            if(!$row && $type==='blog')throw new \RuntimeException('Legacy blog SEO fallback');
            $value=$row?json_decode($row['extra_json'],true):[];
            return self::$cache[$key]=is_array($value)?$value:[];
        }catch(\Throwable $e){
          if($type==='blog'){
            try{
              $row=Database::getInstance()->fetch("SELECT original_author,robots,secondary_keywords,source_json FROM nv_legacy_blog_meta WHERE blog_post_id=?",[$id]);
              if($row){
                $source=json_decode((string)$row['source_json'],true)?:[];
                return self::$cache[$key]=[
                  'author_name'=>$row['original_author']??'',
                  'author_type'=>$source['author_type']??'Organization',
                  'author_url'=>$source['author_url']??'',
                  'robots'=>$row['robots']??'',
                  'secondary_keywords'=>$row['secondary_keywords']??''
                ];
              }
            }catch(\Throwable $ignored){}
          }
          return [];
        }
    }

    public static function save(string $type,int $id,array $input):void
    {
        if(!in_array($type,['package','category','blog'],true)||$id<1)return;
        $data=[];
        foreach([
            'secondary_keywords'=>1000,'robots'=>90,'geo_summary'=>500,
            'entity_topics'=>500,'service_area'=>300,'author_name'=>120,
            'author_type'=>30,'author_url'=>500,'same_as_urls'=>1500,
            'content_intent'=>100,'main_question'=>300,'direct_answer'=>800,
            'sources'=>2500,'reviewer_name'=>120,'last_reviewed'=>35,
            'image_title'=>240
        ] as $field=>$limit){
            $data[$field]=mb_substr(trim((string)($input['nvseo_'.$field]??'')),0,$limit,'UTF-8');
        }
        if(!in_array($data['robots'],[
            '','index,follow','noindex,follow','noindex,nofollow',
            'index,follow,max-image-preview:large'
        ],true))$data['robots']='';
        if(!in_array($data['author_type'],['','Person','Organization'],true))
            $data['author_type']='Organization';
        foreach(['author_url'] as $field){
            if($data[$field]!==''&&!self::urlAllowed($data[$field]))$data[$field]='';
        }
        $profiles=[];
        foreach(preg_split('/\R/', $data['same_as_urls'])?:[] as $candidate){
            $candidate=trim($candidate);
            if(self::urlAllowed($candidate))$profiles[]=$candidate;
        }
        $data['same_as_urls']=implode("\n",array_slice(array_unique($profiles),0,15));
        // New optional preview controls survive legacy/batch form submissions.
        $old=self::get($type,$id);$preview=[];
        foreach(['max_snippet','max_image_preview','max_video_preview']as $field)$preview[$field]=$input['nvseo_'.$field]??$old[$field]??'';
        $data=array_merge($data,SeoMetadataService::preview($preview));
        // An editorial readiness snapshot is informative, not a ranking promise.
        // It is recomputed from the actual saved article, never accepted as a
        // trusted score from a hidden form field.
        if($type==='blog'){
            $post=Database::getInstance()->fetch("SELECT * FROM blog_posts WHERE id=? LIMIT 1",[$id]);
            if($post){
                $assessment=BlogQualityScoreService::evaluate($post,$data);
                $data['quality_scores']=$assessment['scores'];
                $data['quality_checked_at']=date('c');
            }
        }

        $pdo=Database::getInstance()->getPdo();
        // The existing canonical database.sql owns this table. Runtime DDL would
        // implicitly commit an editor's surrounding transaction on MySQL.
        $pdo->prepare("INSERT INTO nv_editorial_seo (entity_type,entity_id,extra_json)
            VALUES(?,?,?) ON DUPLICATE KEY UPDATE extra_json=VALUES(extra_json)")->execute([
            $type,$id,json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)
        ]);
        self::$cache[$type.':'.$id]=$data;
    }

    private static function urlAllowed(string $url):bool
    {
        return filter_var($url,FILTER_VALIDATE_URL)!==false
            && in_array(strtolower((string)parse_url($url,PHP_URL_SCHEME)),['http','https'],true);
    }
}
