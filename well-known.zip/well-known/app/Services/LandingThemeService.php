<?php
namespace App\Services;

/** Landing-only presentation registry. No settings singleton or URL identity changes. */
final class LandingThemeService
{
    public const DEFAULT_KEY='landing-01';
    public static function all():array
    {
        return [
            'landing-01'=>['name'=>'Mavi Ufuk','description'=>'Aydınlık ajans, yatay vitrin, kompakt kartlar','hero'=>'city','services'=>'tiles','scripts'=>'showcase','content'=>'timeline','blog'=>'editorial','faq'=>'split','cta'=>'banner'],
            'landing-02'=>['name'=>'Gece Atlası','description'=>'Lacivert teknoloji, geniş fotoğraf alanı, koyu vitrin','hero'=>'night','services'=>'elevated','scripts'=>'gallery','content'=>'dark-flow','blog'=>'cards','faq'=>'split','cta'=>'wide'],
            'landing-03'=>['name'=>'Yeşil Rota','description'=>'Temiz büyüme, şehir fotoğrafı, açık süreç','hero'=>'growth','services'=>'compact','scripts'=>'gallery','content'=>'steps','blog'=>'cards','faq'=>'columns','cta'=>'ribbon'],
            'landing-04'=>['name'=>'Glass Studio','description'=>'Mor-mavi cam yüzeyler, fotoğraf ve yatay ürünler','hero'=>'glass','services'=>'glass','scripts'=>'horizontal','content'=>'steps','blog'=>'cards','faq'=>'split','cta'=>'glass'],
            'landing-05'=>['name'=>'Editoryal','description'=>'Adaçayı ve krem, kurumsal kartlar, açık süreç','hero'=>'editorial','services'=>'tiles','scripts'=>'gallery','content'=>'steps','blog'=>'cards','faq'=>'columns','cta'=>'ribbon'],
            'landing-06'=>['name'=>'Yerel Odak','description'=>'Yeşil yerel hizmet, ters yerleşim ve sade satırlar','hero'=>'local','services'=>'rows','scripts'=>'showcase','content'=>'alternating','blog'=>'list','faq'=>'split','cta'=>'ribbon'],
            'landing-07'=>['name'=>'Turuncu İvme','description'=>'Lacivert-turuncu, geniş ürün vitrini ve teklif odağı','hero'=>'conversion','services'=>'compact','scripts'=>'wide-covers','content'=>'steps','blog'=>'editorial','faq'=>'split','cta'=>'banner'],
            'landing-08'=>['name'=>'SaaS Minimal','description'=>'Antrasit, geniş görsel alanı ve minimal çizgiler','hero'=>'saas','services'=>'list','scripts'=>'gallery','content'=>'timeline','blog'=>'list','faq'=>'columns','cta'=>'minimal'],
            'landing-09'=>['name'=>'Prizma','description'=>'Mavi-mor gradyan, fotoğraf ve bento kartlar','hero'=>'prism','services'=>'bento','scripts'=>'showcase','content'=>'steps','blog'=>'cards','faq'=>'split','cta'=>'banner'],
            'landing-10'=>['name'=>'Boyut','description'=>'Lacivert-beyaz, geniş fotoğraf ve ferah vitrin','hero'=>'dimension','services'=>'tiles','scripts'=>'wide-covers','content'=>'steps','blog'=>'editorial','faq'=>'split','cta'=>'glass'],
        ];
    }
    /** Empty/unknown keys preserve the existing Studio/Editorial presentation. */
    public static function key(mixed $value):string
    {return is_string($value)&&isset(self::all()[$value])?$value:'';}
    public static function profile(string $key):array
    {return self::all()[self::key($key)]??self::all()[self::DEFAULT_KEY];}
    public static function variant(array $profile,string $type):string
    {return $profile[$type]??'generic';}
    /** One normalized block stream; every enabled existing block survives all themes. */
    public static function blocks(array $d,array $sources):array
    {
        $available=['overview'=>$d['local_context']!=='','services'=>!empty($sources['services']),'scripts'=>!empty($sources['scripts']),'references'=>!empty($sources['references']),'content'=>!empty($d['sections']),'answer'=>$d['seo']['direct_answer']!==''||$d['seo']['geo_summary']!=='','blog'=>!empty($sources['blog']),'faq'=>!empty($d['faqs'])];
        $blocks=[];
        foreach($d['section_order'] as $key)if(in_array($key,$d['enabled_sections'],true)&&!empty($available[$key]))$blocks[]=['type'=>$key,'title'=>RegionalLandingService::SECTIONS[$key]];
        return $blocks;
    }
    public static function component(string $type):string
    {return in_array($type,array_keys(RegionalLandingService::SECTIONS),true)?'block.php':'generic.php';}
}
