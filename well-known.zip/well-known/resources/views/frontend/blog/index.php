<?php
$featured = $posts[0] ?? null;
$gridPosts = $featured ? array_slice($posts, 1) : $posts;
$recentComments = $testimonialSection['extra'] ?? [];
if (!function_exists('yvBlogPlatform')) {
    function yvBlogPlatform(string $name=''): array {
        $s = mb_strtolower($name);
        if (str_contains($s,'google')) return ['google','google'];
        if (str_contains($s,'instagram')) return ['instagram','instagram'];
        if (str_contains($s,'tiktok')) return ['tiktok','tiktok'];
        if (str_contains($s,'youtube')) return ['youtube','youtube'];
        if (str_contains($s,'seo') || str_contains($s,'web')) return ['web','globe'];
        return ['default','file-text'];
    }
}
?>
<div class="yv-blog-v8">
<section class="yv-blog-hero-v8">
  <div class="container">
    <div class="breadcrumb"><a href="/">Anasayfa</a><span class="separator">/</span><span>Blog / Bilgi Merkezi</span></div>
    <div class="yv-blog-hero-grid-v8">
      <div class="yv-blog-hero-copy-v8">
        <div class="yv-kicker"><?= icon('file-text',12) ?> Blog / Bilgi Merkezi</div>
        <h1>Dijital Başarınız İçin<br><span>Güncel Bilgiler, Rehberler ve İpuçları!</span></h1>
        <p>Sosyal medya, Google, web siteniz ve daha fazlası için uzman bilgileri, stratejileri ve pratik rehberleri keşfedin. NetVera Teknoloji Yazılım blogu ile dijital dünyada her zaman bir adım önde olun.</p>
        <form class="yv-blog-search-v8" method="GET" action="/blog">
          <?= icon('search',15) ?>
          <input name="q" value="<?= e($_GET['q']??'') ?>" aria-label="Blog yazılarında ara" placeholder="Hangi konuda bilgi arıyorsunuz?">
          <button type="submit">Ara <?= icon('arrow-right',11) ?></button>
        </form>
        <div class="yv-blog-hot-v8"><small>En çok aranan konular:</small><span>Hazır Yazılım</span><span>Instagram Takipçi</span><span>Dijital Ajans</span><span>Teknik SEO</span></div>
      </div>
      <div class="yv-blog-hero-art-v8" aria-label="NetVera bilgi merkezi içerik önizlemesi">
        <div class="nv-blog-preview-v2" aria-hidden="true">
          <div class="nv-blog-preview-toolbar-v2">
            <span class="nv-blog-preview-brand-v2"><?= icon('file-text',15) ?> NetVera Bilgi Merkezi</span>
            <span class="nv-blog-preview-window-v2"><i></i><i></i><i></i></span>
          </div>
          <div class="nv-blog-preview-body-v2">
            <div class="nv-blog-preview-lead-v2">
              <span class="nv-blog-preview-eyebrow-v2">DİJİTAL REHBERLER</span>
              <strong>Bilgiyle büyüyen<br>fikirler.</strong>
              <p>İşinizi geliştiren içerikler, bir arada.</p>
              <div class="nv-blog-preview-tags-v2"><span>SEO</span><span>Yapay Zekâ</span><span>Sosyal Medya</span></div>
            </div>
            <div class="nv-blog-preview-articles-v2">
              <div><span><?= icon('search',17) ?></span><p><strong>Arama görünürlüğü</strong><small>SEO ve GEO rehberleri</small></p></div>
              <div><span><?= icon('robot',17) ?></span><p><strong>Yapay zekâ</strong><small>Otomasyon ve araçlar</small></p></div>
              <div><span><?= icon('trending-up',17) ?></span><p><strong>Dijital strateji</strong><small>Güncel ipuçları</small></p></div>
            </div>
          </div>
          <div class="nv-blog-preview-bottom-v2"><span><i></i> Yeni fikirler, güvenilir rehberler</span><?= icon('arrow-up-right',16) ?></div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="yv-blog-categories-v8">
  <div class="container">
    <div class="yv-blog-chip-grid-v8">
      <a class="<?= empty($_GET['category'])?'active':'' ?>" href="/blog"><?= icon('grid',14) ?><span>Tümü</span></a>
      <?php foreach(array_slice($categories,0,9) as $cat): [$cls,$ico]=yvBlogPlatform($cat['name']??''); ?>
      <a class="<?= (($_GET['category']??'')===$cat['slug'])?'active':'' ?>" href="/blog/kategori/<?= rawurlencode((string)$cat['slug']) ?>"><?= icon($ico,14) ?><span><?= e($cat['name']) ?></span></a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="yv-blog-main-v8">
  <div class="container">
    <div class="yv-blog-layout-v8">
      <main>
        <?php if($featured): ?>
        <article class="yv-blog-featured-v8">
          <div class="yv-blog-featured-copy-v8">
            <span>ÖNE ÇIKAN YAZI</span>
            <h2><?= e($featured['title']) ?></h2>
            <p><?= e(excerpt(strip_tags($featured['excerpt']??$featured['content']??''),170)) ?></p>
            <div class="yv-blog-featured-meta-v8"><small><?= !empty($featured['published_at'])?formatDate($featured['published_at'],'d M Y'):'Güncel' ?></small><small><?= (int)($featured['views']??0) ?> okunma</small></div>
            <a href="/blog/<?= e($featured['slug']) ?>">Yazıyı Oku <?= icon('arrow-right',11) ?></a>
          </div>
          <div class="yv-blog-featured-media-v8">
            <img class="yv-blog-featured-backdrop-v2" src="<?= e(!empty($featured['image']) ? upload_url($featured['image']) : demo_visual_url($featured['title'].' '.($featured['category_name']??''),'featured blog')) ?>" alt="" aria-hidden="true" loading="lazy">
            <img class="yv-blog-featured-photo-v12" src="<?= e(!empty($featured['image']) ? upload_url($featured['image']) : demo_visual_url($featured['title'].' '.($featured['category_name']??''),'featured blog')) ?>" alt="<?= e($featured['image_alt']??$featured['title']) ?>">
          </div>
        </article>
        <?php endif; ?>

        <div class="yv-blog-head-v8"><div><h2>Son Yazılar</h2><p>Güncel rehberler, stratejiler ve uzman içerikleri ile dijital dünyada fark yaratın.</p></div><a href="/blog">Tüm Yazılar <?= icon('arrow-right',10) ?></a></div>

        <?php if(!empty($gridPosts)): ?>
        <div class="yv-blog-post-grid-v8">
          <?php foreach($gridPosts as $post): [$cls,$ico]=yvBlogPlatform($post['category_name']??$post['title']); ?>
          <a class="yv-blog-post-card-v8 <?= e($cls) ?>" href="/blog/<?= e($post['slug']) ?>">
            <div class="yv-blog-post-image-v8"><img src="<?= e(!empty($post['image']) ? upload_url($post['image']) : demo_visual_url($post['title'].' '.($post['category_name']??''),'blog card')) ?>" alt="<?= e($post['image_alt']??$post['title']) ?>"><b><?= e($post['category_name']??'Rehber') ?></b></div>
            <div class="yv-blog-post-body-v8"><h3><?= e($post['title']) ?></h3><p><?= e(excerpt(strip_tags($post['excerpt']??$post['content']??''),105)) ?></p><div><span><?= icon('calendar',10) ?> <?= !empty($post['published_at'])?formatDate($post['published_at'],'d M Y'):'Güncel' ?></span><span><?= icon('eye',10) ?> <?= number_format((int)($post['views']??0)) ?> okunma</span></div></div>
          </a>
          <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="yv-empty"><div class="yv-empty-icon"><?= icon('search',30) ?></div><h2>İçerik bulunamadı</h2><p>Arama veya filtre kriterlerine uygun yazı bulunamadı.</p></div>
        <?php endif; ?>

        <?php if($totalPages>1): ?><div class="pagination yv-blog-pagination-v8"><?php for($i=1;$i<=$totalPages;$i++): ?><a class="<?= $i==$page?'active':'' ?>" href="<?= e(\App\Services\PublicSeoUrls::withQuery($blogPaginationBase ?? '/blog', array_merge(array_diff_key($_GET,array_flip(['category','tag'])),['page'=>$i]))) ?>"><?= $i ?></a><?php endfor; ?></div><?php endif; ?>
      </main>

      <aside class="yv-blog-sidebar-v8">
        <section class="yv-blog-side-card-v8"><div class="yv-blog-side-title-v8"><h3><?= icon('trending-up',14) ?> Popüler Yazılar</h3><a href="/blog">Tümünü Gör</a></div><?php foreach($popularPosts as $i=>$post): ?><a class="yv-blog-popular-v8" href="/blog/<?= e($post['slug']) ?>"><b><?= $i+1 ?></b><span><img src="<?= e(!empty($post['image']) ? upload_url($post['image']) : demo_visual_url($post['title'].' '.($post['category_name']??''),'blog thumb')) ?>" alt="<?= e($post['title']) ?>"></span><div><strong><?= e(excerpt($post['title'],48)) ?></strong><small><?= number_format((int)($post['views']??0)) ?> okunma</small></div></a><?php endforeach; ?></section>

        <?php if(!empty($recentComments)): ?><section class="yv-blog-side-card-v8"><div class="yv-blog-side-title-v8"><h3><?= icon('message-circle',14) ?> Son Yorumlar</h3><a href="#">Tümünü Gör</a></div><?php foreach(array_slice($recentComments,0,5) as $i=>$review): ?><div class="yv-blog-comment-v8"><span><?= mb_strtoupper(mb_substr($review['name']??'M',0,1)) ?></span><div><strong><?= e($review['name']??'Müşteri') ?></strong><p><?= e(excerpt($review['text']??'',52)) ?></p></div><small><?= $i<2?'2 saat önce':'1 gün önce' ?></small></div><?php endforeach; ?></section><?php endif; ?>

        <section class="yv-blog-news-v8"><div class="yv-blog-news-icon-v8"><?= icon('mail',22) ?></div><h3>E-Bülten'e Abone Olun</h3><p>En yeni içerikler, özel ipuçları ve kampanyalardan ilk siz haberdar olun.</p><form method="POST" action="/bulten/kayit"><?= csrfField() ?><input type="hidden" name="source" value="blog"><input type="hidden" name="return_to" value="/blog"><div class="yv-honeypot" aria-hidden="true"><label>Web sitesi<input name="website_url" type="text" tabindex="-1" autocomplete="off"></label></div><input type="email" name="email" autocomplete="email" aria-label="Bülten e-posta adresi" placeholder="E-posta adresinizi girin" required><label class="yv-opt-in blog-opt-in"><input type="checkbox" name="newsletter_consent" value="1" required><span><a href="/sayfa/kvkk" target="_blank" rel="noopener">KVKK bilgilendirmesini</a> okudum ve bülten almak istiyorum.</span></label><button type="submit">Abone Ol <?= icon('arrow-right',10) ?></button></form></section>
      </aside>
    </div>
  </div>
</section>

<section class="yv-blog-benefits-v8"><div class="container"><h2>Neden Bilgi Merkezimizi Takip Etmelisiniz?</h2><p>Dijital dünyada doğru bilgi, doğru strateji ve sürdürülebilir başarı için yanınızdayız.</p><div><span><?= icon('award',19) ?><b>Uzman İçerikler</b><small>Alanında uzman ekibimiz tarafından hazırlanan rehberler.</small></span><span><?= icon('zap',19) ?><b>Güncel Bilgiler</b><small>Sürekli güncellenen içeriklerle her zaman güncel kalın.</small></span><span><?= icon('bar-chart',19) ?><b>Uygulanabilir Stratejiler</b><small>Hemen uygulayabileceğiniz pratik ipuçları ve taktikler.</small></span><span><?= icon('shield',19) ?><b>Güvenilir Kaynak</b><small>Deneyim ve gerçek verilere dayalı, şeffaf bilgiler.</small></span></div></div></section>

<?php if(!empty($faqs)): ?><section class="yv-blog-faq-v8"><div class="container"><div class="yv-blog-head-v8"><div><h2>Sıkça Sorulan Sorular</h2></div><a href="/sss">Tüm Soruları Gör <?= icon('arrow-right',10) ?></a></div><div class="yv-blog-faq-grid-v8"><?php foreach($faqs as $faq): ?><div><button type="button"><span><?= e($faq['question']) ?></span><?= icon('plus',11) ?></button><p><?= nl2br(e($faq['answer'])) ?></p></div><?php endforeach; ?></div></div></section><?php endif; ?>

<section class="yv-blog-final-v8"><div class="container"><div><?= icon('file-text',23) ?><span><strong>Bilgi ile Daha Güçlü Olun!</strong><small>Sosyal medya, Google ve dijital pazarlama hakkında en güncel rehberleri keşfedin.</small></span></div><a href="/blog">Tüm Yazıları Keşfet <?= icon('arrow-right',11) ?></a><div class="yv-blog-avatars-v8"><span>A</span><span>E</span><span>M</span><b>+50.000<small>Mutlu Takipçi</small></b></div></div></section>
</div>
<script>document.querySelectorAll('.yv-blog-faq-grid-v8 button').forEach(btn=>btn.addEventListener('click',()=>{const p=btn.nextElementSibling;p.style.display=p.style.display==='block'?'none':'block'}));</script>
