<div class="adm-page-top">
    <div>
        <h2><?= icon('package', 24) ?> Paketler</h2>
    </div>
    <div class="adm-page-top-badges">
        <form method="POST" action="/admin/paketler/yayinla" style="margin:0" onsubmit="return confirm('Mevcut tüm kayıtlı paketler ile ilişkili kategorileri aktif edip vitrinde yayımlamak istiyor musunuz? Fiyatlar ve paket detayları değişmeyecek.')">
            <?= csrfField() ?>
            <button type="submit" class="btn btn-primary btn-sm"><?= icon('check-circle',14) ?> Kataloğu Yayına Al</button>
        </form>
        <form method="POST" action="/admin/paketler/seo-tamamla" style="margin:0" onsubmit="return confirm('Hazır yazılımlar, URL yapıları, mevcut özgün içerikler ve fiyatlar korunarak yalnızca boş/eski SEO alanları tamamlansın mı?')">
            <?= csrfField() ?>
            <button type="submit" class="btn btn-outline btn-sm"><?= icon('search',14) ?> Hizmet SEO / GEO / AIO Tamamla</button>
        </form>
        <a href="/admin/import" class="btn btn-outline btn-sm"><?= icon('upload', 14) ?> Excel/CSV İçe Aktar</a>
        <a href="/admin/paket/ekle" class="btn btn-primary btn-sm"><?= icon('plus', 16) ?> Paket Ekle</a>
    </div>
</div>

<div class="adm-catalog-status" role="status">
    <span><?= icon('package',14) ?> <strong><?= (int)($catalogStats['total']??0) ?></strong> kayıtlı paket</span>
    <span><?= icon('check-circle',14) ?> <strong><?= (int)($catalogStats['active']??0) ?></strong> aktif</span>
    <span><?= icon('eye',14) ?> <strong><?= (int)($catalogStats['visible']??0) ?></strong> vitrinde</span>
    <?php if(!empty($catalogStats['blocked'])): ?><span class="adm-catalog-alert"><?= icon('alert-circle',14) ?> <?= (int)$catalogStats['blocked'] ?> aktif paket kategori nedeniyle gizli</span><?php endif; ?>
    <span><?= icon('eye-off',14) ?> <strong><?= (int)($catalogStats['hidden']??0) ?></strong> pasif</span>
    <?php if(!empty($catalogStats['missing_category'])): ?><span class="adm-catalog-alert"><?= icon('alert-circle',14) ?> <?= (int)$catalogStats['missing_category'] ?> paketin kategorisi bulunamıyor</span><?php endif; ?>
    <a href="/kategoriler" target="_blank" rel="noopener"><?= icon('external-link',13) ?> Vitrini Aç</a>
</div>

<?php if (empty($packages)): ?>
<div class="adm-card">
    <div class="adm-card-body">
        <div class="adm-empty-sm" style="padding: var(--space-8);"><?= icon('package', 32) ?><p>Henüz paket eklenmemiş.</p></div>
    </div>
</div>
<?php else: ?>

<form method="POST" action="/admin/paketler/toplu-islem" id="bulkPkgForm">
<?= csrfField() ?>
<div class="adm-bulk-actions" id="bulkPkgActions" style="display:none; padding: 12px; background: var(--color-surface); border: 1px solid var(--color-border); border-radius: 6px; margin-bottom: 16px; align-items: center; gap: 12px;">
    <span class="text-sm font-semibold"><span id="selectedPkgCount">0</span> paket seçildi</span>
    <select name="action" class="form-control form-control-sm" style="width: auto;" id="bulkPkgActionSelect" onchange="toggleCategorySelect()" required>
        <option value="">Toplu İşlem Seç...</option>
        <option value="active">Aktif Et</option>
        <option value="inactive">Pasife Al</option>
        <option value="featured">Öne Çıkar</option>
        <option value="unfeatured">Öne Çıkanlardan Kaldır</option>
        <option value="change_category">Kategoriyi Değiştir</option>
        <option value="delete">Sil (Pasife Alır/Siler)</option>
    </select>
    
    <select name="new_category_id" id="bulkCategorySelect" class="form-control form-control-sm" style="display:none; width: auto;">
        <option value="">Kategori Seçin...</option>
        <?php foreach($categories ?? [] as $c): ?>
            <option value="<?= $c['id'] ?>"><?= e($c['name']) ?></option>
        <?php endforeach; ?>
    </select>

    <button type="submit" class="btn btn-primary btn-sm" onclick="return confirm('Seçili paketler için bu işlemi yapmak istediğinize emin misiniz?')">Uygula</button>
</div>

<!-- Desktop Table -->
<div class="adm-card adm-pkg-desktop">
    <div class="adm-card-body adm-table-scroll" style="padding: 0;">
        <table class="adm-table">
            <thead>
                <tr>
                    <th width="40"><input type="checkbox" id="selectAllPkgs" onchange="toggleAllPkgs(this)"></th>
                    <th>Paket Adı</th>
                    <th>Kategori</th>
                    <th>Fiyat</th>
                    <th>İnd. Fiyat</th>
                    <th>Teslimat</th>
                    <th>Adet</th>
                    <th>SEO</th>
                    <th>Durum</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($packages as $pkg): ?>
                <tr>
                    <td><input type="checkbox" name="ids[]" value="<?= $pkg['id'] ?>" class="pkg-checkbox" onchange="updatePkgBulkActions(this)"></td>
                    <td>
                        <div class="adm-pkg-name">
                            <span class="font-semibold"><?= e(package_display_name($pkg)) ?></span>
                            <?php if (!empty($pkg['is_featured'])): ?>
                            <span class="adm-featured-badge"><?= icon('star', 10) ?> Öne Çıkan</span>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td>
                        <span class="adm-cat-badge"><?= icon($pkg['icon_key'] ?? 'package', 12) ?> <?= e($pkg['category_name'] ?? '-') ?></span>
                    </td>
                    <td class="font-semibold"><?= money($pkg['price']) ?></td>
                    <td>
                        <?php if ($pkg['discount_price']): ?>
                        <span class="font-semibold" style="color: var(--color-green);"><?= money($pkg['discount_price']) ?></span>
                        <?php else: ?>
                        <span class="text-secondary">-</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-sm"><?= e($pkg['delivery_time'] ?? '-') ?></td>
                    <td class="text-xs text-secondary"><?= $pkg['min_quantity'] ?>-<?= $pkg['max_quantity'] ?></td>
                    <td>
                        <?php $seoScore = $pkg['seo_score'] ?? 0; ?>
                        <span class="adm-seo-pill <?= $seoScore >= 80 ? 'seo-good' : ($seoScore >= 50 ? 'seo-ok' : 'seo-bad') ?>"><?= $seoScore ?></span>
                    </td>
                    <td>
                        <span class="status-badge <?= $pkg['status'] === 'active' ? 'success' : 'default' ?>"><?= $pkg['status'] === 'active' ? 'Aktif' : 'Pasif' ?></span>
                    </td>
                    <td>
                        <div class="adm-actions">
                            <a href="/admin/paket/<?= $pkg['id'] ?>/alanlar" class="adm-action-btn" title="Alanlar"><?= icon('list', 14) ?></a>
                            <a href="/admin/paket/<?= $pkg['id'] ?>/duzenle" class="adm-action-btn" title="Düzenle"><?= icon('edit', 14) ?></a>
                            <button type="submit" class="adm-action-btn adm-action-danger" formaction="/admin/paket/<?= $pkg['id'] ?>/sil" formnovalidate onclick="return confirm('Bu paketi silmek istediğinize emin misiniz?')" title="Sil"><?= icon('trash', 14) ?></button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Mobile Cards -->
<div class="adm-pkg-mobile">
    <div style="padding: 12px; display:flex; align-items:center; gap: 8px; border-bottom: 1px solid var(--color-border);">
        <input type="checkbox" id="selectAllPkgsMobile" onchange="toggleAllPkgs(this)"> 
        <label for="selectAllPkgsMobile" class="text-sm font-semibold">Tümünü Seç</label>
    </div>
    <?php foreach ($packages as $pkg): ?>
    <div class="adm-order-card-m">
        <div class="adm-order-card-m-top">
            <div style="display:flex; align-items:center; gap: 8px;">
                <input type="checkbox" name="ids[]" value="<?= $pkg['id'] ?>" class="pkg-checkbox" onchange="updatePkgBulkActions(this)">
                <span class="font-semibold"><?= e(package_display_name($pkg)) ?></span>
                <?php if (!empty($pkg['is_featured'])): ?>
                <span class="adm-featured-badge"><?= icon('star', 10) ?></span>
                <?php endif; ?>
            </div>
            <span class="status-badge <?= $pkg['status'] === 'active' ? 'success' : 'default' ?>"><?= $pkg['status'] === 'active' ? 'Aktif' : 'Pasif' ?></span>
        </div>
        <div class="adm-order-card-m-body">
            <div class="adm-order-card-m-row">
                <span class="adm-order-card-m-label">Kategori</span>
                <span class="text-sm"><?= e($pkg['category_name'] ?? '-') ?></span>
            </div>
            <div class="adm-order-card-m-row">
                <span class="adm-order-card-m-label">Fiyat</span>
                <div>
                    <strong><?= money($pkg['price']) ?></strong>
                    <?php if ($pkg['discount_price']): ?>
                    <span class="text-xs" style="color: var(--color-green);"> / <?= money($pkg['discount_price']) ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="adm-order-card-m-row">
                <span class="adm-order-card-m-label">Teslimat</span>
                <span class="text-sm"><?= e($pkg['delivery_time'] ?? '-') ?></span>
            </div>
            <div class="adm-order-card-m-row">
                <span class="adm-order-card-m-label">SEO</span>
                <?php $seoScore = $pkg['seo_score'] ?? 0; ?>
                <span class="adm-seo-pill <?= $seoScore >= 80 ? 'seo-good' : ($seoScore >= 50 ? 'seo-ok' : 'seo-bad') ?>"><?= $seoScore ?></span>
            </div>
        </div>
        <div class="adm-card-m-actions">
            <a href="/admin/paket/<?= $pkg['id'] ?>/alanlar" class="adm-order-card-m-action" style="border-right: 1px solid var(--color-border);"><?= icon('list', 14) ?> Alanlar</a>
            <a href="/admin/paket/<?= $pkg['id'] ?>/duzenle" class="adm-order-card-m-action" style="border-right: 1px solid var(--color-border);"><?= icon('edit', 14) ?> Düzenle</a>
            <button type="submit" class="adm-order-card-m-action" formaction="/admin/paket/<?= $pkg['id'] ?>/sil" formnovalidate onclick="return confirm('Bu paketi silmek istediğinize emin misiniz?')" style="flex:1;width:100%;color:var(--color-red);border:none;background:none;cursor:pointer;font-family:var(--font-family);"><?= icon('trash', 14) ?> Sil</button>
        </div>
    </div>
    <?php endforeach; ?>
</div>
</form>

<script>
function toggleAllPkgs(source) {
    const checkboxes = document.querySelectorAll('.pkg-checkbox');
    checkboxes.forEach(cb => cb.checked = source.checked);
    document.getElementById('selectAllPkgs').checked = source.checked;
    if (document.getElementById('selectAllPkgsMobile')) {
        document.getElementById('selectAllPkgsMobile').checked = source.checked;
    }
    updatePkgBulkActions();
}

function updatePkgBulkActions(source = null) {
    // Desktop and mobile render the same records: mirror selection between layouts.
    if (source) {
        document.querySelectorAll('.pkg-checkbox').forEach(cb => {
            if (cb !== source && cb.value === source.value) cb.checked = source.checked;
        });
    }
    const checkedCount = new Set([...document.querySelectorAll('.pkg-checkbox:checked')].map(cb => cb.value)).size;
    const bulkBar = document.getElementById('bulkPkgActions');
    const countSpan = document.getElementById('selectedPkgCount');
    
    if (checkedCount > 0) {
        bulkBar.style.display = 'flex';
        countSpan.textContent = checkedCount;
    } else {
        bulkBar.style.display = 'none';
    }
}

function toggleCategorySelect() {
    const action = document.getElementById('bulkPkgActionSelect').value;
    const catSelect = document.getElementById('bulkCategorySelect');
    if (action === 'change_category') {
        catSelect.style.display = 'inline-block';
        catSelect.required = true;
    } else {
        catSelect.style.display = 'none';
        catSelect.required = false;
    }
}
</script>
<?php endif; ?>
