<?php
use App\Services\RegionalLandingService as Landing;
$d=$landing;
$editorPreviewImage='';
try{$editorPreviewImage=\App\Services\LandingContentService::image($d['location_image']??'');}catch(\InvalidArgumentException $ignored){}
$editorField=static function(string $label,string $name,string $value,int $max=180,int $rows=1):void{
    $id='landing-field-'.substr(hash('sha256',$name),0,12);
    echo '<div class="form-group"><label for="'.$id.'">'.e($label).'</label>';
    if($rows>1)echo '<textarea class="form-control" id="'.$id.'" name="'.e($name).'" rows="'.$rows.'" maxlength="'.$max.'">'.e($value).'</textarea>';
    else echo '<input class="form-control" id="'.$id.'" name="'.e($name).'" maxlength="'.$max.'" value="'.e($value).'">';
    echo '</div>';
};
$builderTabs=['basic'=>['file-text','Genel bilgiler'],'visual'=>['image','Görünüm & düzen'],'body'=>['file-text','Sayfa içeriği'],'services'=>['layers','Hizmetler'],'scripts'=>['code','Hazır yazılımlar'],'blog'=>['file-text','Blog yazıları'],'references'=>['image','Referanslar'],'faq'=>['help-circle','SSS'],'editorial'=>['book-open','Yerel rehber / AIO'],'seo'=>['search','SEO & yayın']];
?>
<div class="landing-editor regional-editor">
<form method="post" action="/admin/konumsal-sayfalar/kaydet" enctype="multipart/form-data" data-landing-editor data-region-builder>
<?= csrfField() ?><input type="hidden" name="id" value="<?= (int)($landingRow['id']??0) ?>"><input type="hidden" name="revision" value="<?= e($landingRevision) ?>">
<header class="region-editor-header"><div><a class="region-editor-back" href="/admin/konumsal-sayfalar">← Konumsal sayfalar</a><h2><?= $landingRow?'Sayfayı düzenle':'Yeni şehir sayfası' ?></h2><p data-builder-name><?= e($d['title']?:'Başlığınızı ekleyerek başlayın') ?></p></div><div class="region-editor-header-actions"><span class="region-editor-public-state <?= ($landingRow['status']??'inactive')==='active'?'is-live':'' ?>"><?= ($landingRow['status']??'inactive')==='active'?'Yayında':'Taslak' ?></span><span class="region-editor-state" data-builder-state><?= $landingRow?'Kayıtlı içerik':'Kaydedilmemiş taslak' ?></span><?php if($landingRow): ?><a class="btn btn-outline" href="/<?= rawurlencode($landingRow['slug']) ?>?onizleme=1" target="_blank" rel="noopener">Önizle ↗</a><?php endif; ?><button class="btn btn-primary" type="submit">Değişiklikleri kaydet</button></div></header>
<div class="region-editor-workspace">
    <aside class="region-editor-sidebar"><nav aria-label="Sayfa oluşturma adımları" data-builder-tabs><?php foreach($builderTabs as $key=>[$icon,$label]): ?><a id="builder-tab-<?= $key ?>" href="#landing-<?= $key ?>" data-builder-tab="<?= $key ?>"><?= icon($icon,18) ?><span><?= $label ?></span><?php if(in_array($key,['services','scripts','blog','references'],true)): ?><small data-selection-count="<?= $key ?>"><?= count($d[['services'=>'service_ids','scripts'=>'script_ids','blog'=>'blog_ids','references'=>'reference_ids'][$key]]) ?></small><?php endif; ?></a><?php endforeach; ?></nav><div class="region-editor-sidebar-note"><?= icon('shield',18) ?><p>Seçtiğiniz içeriklerin asıl kayıtları değişmez. İletişim bilgileri sitenizin ortak ayarlarından alınır.</p></div></aside>
    <div class="region-editor-panels">
    <section class="region-editor-panel" id="landing-basic" data-builder-panel="basic" aria-labelledby="builder-tab-basic"><header><span>01 / SAYFA KİMLİĞİ</span><h2>Ne sunuyorsunuz, nerede?</h2><p>Sayfanın temel bilgileri. Konum, hizmet bölgesini tanımlar; şube adresi oluşturmaz.</p></header><div class="adm-card"><div class="adm-card-body">
        <?php $editorField('Sayfa başlığı (H1)','title',$d['title']);$editorField('Sayfa adresi — örn. alanya-reklam-ajansi','slug',$d['slug']); ?>
        <p class="landing-editor-help">Adres değiştiğinde eski URL otomatik 301 ile korunur.</p><div class="landing-editor-grid"><?php foreach(['city'=>['Şehir / ilçe',100],'province'=>['İl',100],'service'=>['Hizmet adı',160],'area'=>['Ayrıntılı hizmet bölgesi',300]]as $key=>[$label,$max])$editorField($label,$key,$d[$key],$max); ?></div>
        <?php $editorField('Kısa tanıtım / hero açıklaması','summary',$d['summary'],600,3);$editorField('Bölgesel kapsam — bu sayfa kime, nasıl yardımcı oluyor?','local_context',$d['local_context'],3000,5); ?>
        <p class="landing-editor-help">Şehir adını değiştiren kopyalar yerine bölgeye ve hizmete özgü bilgi yazın.</p>
    </div></div></section>
    <section class="region-editor-panel" id="landing-visual" data-builder-panel="visual" aria-labelledby="builder-tab-visual"><header><span>02 / GÖRSEL DİL</span><h2>Sayfanın görünümünü belirleyin.</h2><p>Görselinizi, renk yaklaşımını ve bölüm sırasını tek yerden yönetin.</p></header><div class="adm-card"><div class="adm-card-body">
        <?php require __DIR__.'/theme-picker.php'; ?>
        <details class="landing-editor-details"><summary>Eski Studio / Editorial görünüm ayarları</summary><div class="landing-editor-fields"><p class="landing-editor-help">Yalnızca “Eski görünümü koru” seçeneğinde geçerlidir. Yeni temaların renk ve yerleşimleri kendi tasarımlarına aittir.</p>
        <div class="landing-editor-grid"><?php foreach(['layout'=>['Tasarım yaklaşımı',['studio'=>'Studio — koyu premium hero','editorial'=>'Editorial — açık kurumsal görünüm']],'theme'=>['Vurgu rengi',['violet'=>'NetVera mor','blue'=>'Kurumsal mavi','rose'=>'Sosyal pembe']]]as $key=>[$label,$options]): ?><div class="form-group"><label for="landing-<?= $key ?>"><?= $label ?></label><select id="landing-<?= $key ?>" class="form-control" name="<?= $key ?>"><?php foreach($options as $value=>$text): ?><option value="<?= $value ?>" <?= $d[$key]===$value?'selected':'' ?>><?= $text ?></option><?php endforeach; ?></select></div><?php endforeach; ?></div>
        <div class="region-design-preview"><div><span>NETVERA / DİJİTAL ÇÖZÜMLER</span><strong data-design-title><?= e($d['title']?:'Şehriniz için güçlü bir başlangıç.') ?></strong><small>Özgün kapsam · Seçili hizmetler · Doğrudan iletişim</small></div><?php if($editorPreviewImage!==''): ?><img src="<?= e($editorPreviewImage) ?>" alt="Kayıtlı banner ön izlemesi" width="480" height="320"><?php endif; ?></div>
        </div></details>
        <?php // Preserve previous artwork metadata for SEO/backward compatibility; it is no longer rendered in the slider.
        foreach(['image','mobile_image','image_alt'] as $legacyImageField): ?><input type="hidden" name="<?= $legacyImageField ?>" value="<?= e($d[$legacyImageField]) ?>"><?php endforeach; ?>
        <h3>Slider arka plan görseli</h3><p class="landing-editor-help">Sayfayı oluştururken veya düzenlerken bilgisayarınızdan kendi görselinizi yükleyebilirsiniz. Sağ taraftaki reklam illüstrasyonları kaldırılmıştır. Seçtiğiniz arka plan bu sayfanın tüm temalarında kullanılır; diğer sayfaları değiştirmez. Aynı görsel bölgesel kapsam ve iletişim bandında da kullanılır. Boş bırakırsanız temanın renkli zemini gösterilir.</p>
        <fieldset class="region-city-scenes" data-city-scenes><legend>Hazır şehir görselleri</legend><p>AI ile oluşturulmuş temsili görsellerdir; gerçek çekim, ofis veya şube kanıtı değildir. İlgili şehri seçebilir ya da aşağıdan kendi görselinizi yükleyebilirsiniz. Seçim yalnızca bu sayfanın görsel alanına uygulanır; kaydetmeden yayına geçmez.</p><div class="region-city-scene-grid">
        <?php foreach([['alanya-blue-hour.webp','Alanya','Alanya temsili şehir görseli','Mavi saat · kıyı ve kale'],['istanbul-daylight.webp','İstanbul','İstanbul temsili şehir görseli','Gündüz · kıyı ve şehir silüeti']]as [$sceneFile,$sceneCity,$sceneAlt,$sceneDescription]): $scenePath='/assets/img/landing-scenes/'.$sceneFile; ?>
            <button class="region-city-scene" type="button" data-city-scene="<?= e($scenePath) ?>" data-city-scene-alt="<?= e($sceneAlt) ?>" data-city-scene-name="<?= e($sceneCity) ?>" aria-pressed="<?= ($d['location_image']??'')===$scenePath?'true':'false' ?>" disabled><img src="<?= e($scenePath) ?>" alt="<?= e($sceneAlt) ?>" width="640" height="360" loading="lazy"><span><strong><?= e($sceneCity) ?></strong><small><?= e($sceneDescription) ?></small><em>AI ile oluşturulmuş temsili görsel</em></span><span class="region-city-scene-check" aria-hidden="true"><?= icon('check',14) ?></span></button>
        <?php endforeach; ?>
        </div><div class="region-city-scene-actions"><button class="btn btn-sm btn-outline" type="button" data-city-scene-clear disabled>Görsel kullanma</button><p data-city-scene-status role="status" aria-live="polite">Hazır görseller isteğe bağlıdır. Seçim yapılmadıkça kayıtlı görseliniz değişmez.</p></div><noscript><p>Hazır görsel düğmeleri için JavaScript gerekir. Yerel görsel yolunu veya dosya yükleme alanını kullanabilirsiniz.</p></noscript></fieldset>
        <div class="landing-editor-grid"><div><?php $editorField('Slider arka planı — yerel görsel yolu','location_image',$d['location_image']??'',500); ?><div class="form-group"><label for="upload-location_image">Bilgisayardan slider arka planı yükle</label><input id="upload-location_image" class="form-control" type="file" name="location_image_upload" accept="image/jpeg,image/png,image/webp,image/gif"><small>JPG, PNG, WebP, GIF · en fazla 5 MB · önerilen oran 16:9</small></div></div><div><?php $editorField('Slider arka planı alt metni','location_image_alt',$d['location_image_alt']??'',220); ?></div></div>
    </div></div><div class="adm-card"><div class="adm-card-header"><h3>Bölüm sırası ve görünürlüğü</h3></div><div class="adm-card-body"><p class="landing-editor-help">İçerik seçmediğiniz bölümler sitede görünmez. Sıralama ve görünürlük her sayfa için bağımsızdır.</p><input type="hidden" name="enabled_sections[]" value=""><div class="region-section-order" data-section-order><?php foreach($d['section_order']as $key): ?><div data-order-item><input type="hidden" name="section_order[]" value="<?= e($key) ?>"><label><input type="checkbox" name="enabled_sections[]" value="<?= e($key) ?>" <?= in_array($key,$d['enabled_sections'],true)?'checked':'' ?>><?= e(Landing::SECTIONS[$key]) ?></label><div><button type="button" data-section-move="up" aria-label="<?= e(Landing::SECTIONS[$key]) ?> bölümünü yukarı taşı">↑</button><button type="button" data-section-move="down" aria-label="<?= e(Landing::SECTIONS[$key]) ?> bölümünü aşağı taşı">↓</button></div></div><?php endforeach; ?></div></div></div></section>
    <section class="region-editor-panel" id="landing-body" data-builder-panel="body" aria-labelledby="builder-tab-body"><header><span>03 / ANLATIM</span><h2>İçeriği küçük bölümlerle oluşturun.</h2><p>H2/H3 düzeni otomatik korunur. İç bağlantı: [anlamlı metin](/kategori/ornek).</p></header><div class="adm-card"><div class="adm-card-body"><div data-content-rows>
        <?php for($i=0;$i<12;$i++): $block=$d['sections'][$i]??[]; ?><details class="landing-editor-details" data-content-row <?= $i===0&&!empty($block['title'])?'open':'' ?>><summary>Bölüm <?= $i+1 ?><?= !empty($block['title'])?' — '.e($block['title']):'' ?></summary><div class="landing-editor-fields"><div class="landing-editor-row-actions"><button type="button" class="btn btn-sm btn-outline" data-move-row="up">↑ Yukarı</button><button type="button" class="btn btn-sm btn-outline" data-move-row="down">↓ Aşağı</button><button type="button" class="btn btn-sm btn-outline" data-remove-content-row>Bölümü temizle</button></div>
        <?php foreach(['title'=>['Bölüm başlığı (H2)',220,1],'body'=>['İçerik',6000,6],'subheading'=>['Ara başlık (H3, isteğe bağlı)',220,1],'detail'=>['Ara başlık açıklaması',3000,3],'image'=>['Bölüm görsel yolu (isteğe bağlı)',500,1],'alt'=>['Bölüm görsel alt metni',220,1]]as $key=>[$label,$max,$rows])$editorField($label,'sections['.$i.']['.$key.']',$block[$key]??'',$max,$rows); ?>
        </div></details><?php endfor; ?></div><button type="button" class="btn btn-outline region-add-row" data-add-content-row>+ İçerik bölümü ekle</button>
        <?php $contentHome=false;$contentData=$d;$contentPrefix='';$contentId='landing';require __DIR__.'/content-fields.php'; ?>
    </div></div></section>
    <?php foreach(['services'=>['Hizmetler','Hizmet/kategori sayfalarını seçin. Hazır yazılım ürünleri ayrı sekmededir.','service_ids','services_title',$landingCategories],'scripts'=>['Hazır yazılımlar','Gerçek yazılım kataloğundan ürün seçin. Kartlar ilgili yazılım detayına yönlenir.','script_ids','scripts_title',$landingScripts],'blog'=>['Blog yazıları','Yayınlanmış yazıları bu sayfaya özel bir okuma seçkisine ekleyin.','blog_ids','blog_title',$landingBlogs],'references'=>['Referanslar','Aktif portföy kayıtlarından çalışmalar ekleyin.','reference_ids','references_title',$landingReferences]]as $type=>[$label,$help,$field,$titleField,$rows]): ?>
    <section class="region-editor-panel" id="landing-<?= $type ?>" data-builder-panel="<?= $type ?>" aria-labelledby="builder-tab-<?= $type ?>"><header><span>İÇERİK SEÇKİSİ / <?= e(mb_strtoupper($label,'UTF-8')) ?></span><h2><?= e($label) ?></h2><p><?= e($help) ?> Seçim sırası sitedeki kart sırasıdır.</p></header><div class="adm-card"><div class="adm-card-body"><?php $editorField('Sitede görünecek bölüm başlığı',$titleField,$d[$titleField]??'');$pickerType=$type;$pickerField=$field;$pickerRows=$rows;$pickerSelected=$d[$field];require __DIR__.'/picker.php'; ?></div></div></section>
    <?php endforeach; ?>
    <section class="region-editor-panel" id="landing-faq" data-builder-panel="faq" aria-labelledby="builder-tab-faq">
        <header><span>İÇERİK SEÇKİSİ / SSS</span><h2>Bu landing sayfasının sorularını yönetin.</h2><p>Her sayfada kendi soru ve cevapları kullanılır. Seçilen tema aynı bilgileri kendi SSS tasarımıyla gösterir.</p></header>
        <div class="adm-card"><div class="adm-card-body">
            <?php $editorField('SSS bölümünün başlığı','faq_title',$d['faq_title']); ?>
            <p class="landing-editor-help">En fazla 12 gerçek soru-cevap çifti ekleyin. Boş çiftler yayınlanmaz. Görünürlüğü Görünüm &amp; Düzen → Bölüm sırası ve görünürlüğü alanından değiştirebilirsiniz.</p>
            <div class="region-faq-editor">
                <?php for($i=0;$i<12;$i++): $faq=$d['faqs'][$i]??[]; ?>
                <details class="landing-editor-details" <?= $i===0?'open':'' ?>>
                    <summary><?= icon('help-circle',16) ?> Soru <?= $i+1 ?><?= !empty($faq['question'])?' — '.e($faq['question']):'' ?></summary>
                    <div class="landing-editor-fields">
                        <div class="form-group"><label for="region-faq-question-<?= $i ?>">Soru <?= $i+1 ?></label><input id="region-faq-question-<?= $i ?>" name="faqs[<?= $i ?>][question]" class="form-control" maxlength="240" value="<?= e($faq['question']??'') ?>" placeholder="Örn. Proje süresi nasıl belirlenir?"></div>
                        <div class="form-group"><label for="region-faq-answer-<?= $i ?>">Yanıt <?= $i+1 ?></label><textarea id="region-faq-answer-<?= $i ?>" name="faqs[<?= $i ?>][answer]" class="form-control" maxlength="1800" rows="3" placeholder="Hizmet kapsamınıza uygun açıklayıcı yanıt yazın."><?= e($faq['answer']??'') ?></textarea></div>
                    </div>
                </details>
                <?php endfor; ?>
            </div>
        </div></div>
    </section>
    <section class="region-editor-panel" id="landing-editorial" data-builder-panel="editorial" aria-labelledby="builder-tab-editorial">
        <header><span>ŞEHRE VE HİZMETE ÖZEL UZUN İÇERİK</span>
            <h2>Yerel uzmanlık rehberi ve anlaşılır yanıtlar</h2>
            <p>Yalnız bu landing sayfasında görünür. NetVera'nın gerçek hizmet yaklaşımını, kapsamını, kullanım senaryolarını, çalışma sürecini ve özgün bölgesel ayrıntıları anlatın.
            Sadece şehir adını değiştirerek sayfa çoğaltmayın; doğrulanmamış istatistik veya ofis iddiaları kullanmayın.</p>
        </header>
        <div class="adm-card"><div class="adm-card-body">
            <?php $editorField('Uzun içerik başlığı (H2)','editorial_title',$d['editorial_title']??'',200); ?>
            <?php $editorField('Kısa giriş / doğrudan yanıt','editorial_lead',$d['editorial_lead']??'',650,4); ?>
            <?php $editorField('Detaylı şehir ve hizmet anlatımı (paragraflar, 16.000 karakter)','editorial_body',$d['editorial_body']??'',16000,15); ?>
            <p class="landing-editor-help">İki boş satırla yeni paragraf açın; [hizmetlerimizi keşfedin](/kategoriler) şeklinde güvenli site içi bağlantılar ekleyebilirsiniz.
                İçerik tüm tema seçeneklerinde aynı kalır, tasarımı seçilen tema belirler. Yalnız dolu alanlar gösterilir.</p>
            <h3>Soru–cevap anlatımı</h3>
            <p class="landing-editor-help">İsteğe bağlı en fazla 10 gerçek soru/yanıt ekleyin. Sayfanın ana SSS modülü ayrı çalışmaya devam eder; burada girilen sorular uzun rehberin içinde gösterilir.</p>
            <?php for($i=0;$i<10;$i++): $faq=$d['editorial_qa'][$i]??[]; ?>
            <details class="landing-editor-details" <?= $i===0?'open':'' ?>>
                <summary><?= icon('help-circle',16) ?> Rehber sorusu <?= $i+1 ?><?= !empty($faq['question'])?' — '.e($faq['question']):'' ?></summary>
                <div class="landing-editor-fields">
                    <div class="form-group"><label for="editorial-question-<?= $i ?>">Soru</label><input id="editorial-question-<?= $i ?>" name="editorial_qa[<?= $i ?>][question]" class="form-control" maxlength="240" value="<?= e($faq['question']??'') ?>"></div>
                    <div class="form-group"><label for="editorial-answer-<?= $i ?>">Yanıt</label><textarea id="editorial-answer-<?= $i ?>" name="editorial_qa[<?= $i ?>][answer]" class="form-control" maxlength="1800" rows="4"><?= e($faq['answer']??'') ?></textarea></div>
                </div>
            </details>
            <?php endfor; ?>
        </div></div>
    </section>
    <section class="region-editor-panel" id="landing-seo" data-builder-panel="seo" aria-labelledby="builder-tab-seo"><header><span>SON ADIM / YAYIN</span><h2>Kontrol edin, sonra yayınlayın.</h2><p>SEO alanları, indeksleme ve yayın durumu birbirinden bağımsızdır.</p></header><div class="adm-card"><div class="adm-card-body"><div class="landing-editor-grid"><?php foreach(['status'=>['Sayfa durumu',['inactive'=>'Taslak / yayında değil','active'=>'Yayında']],'working_mode'=>['Çalışma biçimi',['remote'=>'Uzaktan / çevrim içi','hybrid'=>'Uzaktan ve planlı görüşme','onsite'=>'Planlı yerinde çalışma']]]as $key=>[$label,$options]): ?><div class="form-group"><label for="landing-<?= $key ?>"><?= $label ?></label><select id="landing-<?= $key ?>" class="form-control" name="<?= $key ?>"><?php foreach($options as $value=>$text): ?><option value="<?= $value ?>" <?= $d[$key]===$value?'selected':'' ?>><?= $text ?></option><?php endforeach; ?></select></div><?php endforeach; ?></div>
        <?php $editorField('İletişim butonu','cta_label',$d['cta_label'],70);$editorField('Alt iletişim başlığı','cta_title',$d['cta_title']);$editorField('Alt iletişim açıklaması','cta_summary',$d['cta_summary'],500,3); ?>
        <?php $seoForHome=false;$seoPrefix='seo';$seoData=$d['seo'];require __DIR__.'/seo-fields.php'; ?><details class="landing-editor-details"><summary>Yayın kontrol notları</summary><ul><?php foreach($landingNotes as $note): ?><li><?= e($note) ?></li><?php endforeach; ?><li>Sitemap yalnızca yayında, indekslemeye açık ve kendi canonical adresini kullanan sayfaları içerir.</li><li>Otomatik kayıt yoktur. Çıkmadan önce değişiklikleri kaydedin.</li></ul></details>
    </div></div></section>
    <div class="region-editor-step-footer"><button type="button" class="btn btn-outline" data-builder-prev>← Önceki adım</button><button type="button" class="btn btn-outline" data-builder-next>Sonraki adım →</button></div>
    </div>
</div></form></div>
