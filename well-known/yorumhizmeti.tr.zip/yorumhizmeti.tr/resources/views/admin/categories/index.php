<div class="adm-page-top">
    <div>
        <h2><?= icon('grid', 24) ?> Kategoriler</h2>
        <p class="text-sm text-secondary">Hizmet kategorilerinizi yönetin.</p>
    </div>
    <a href="/admin/kategori/ekle" class="btn btn-primary btn-sm"><?= icon('plus', 16) ?> Kategori Ekle</a>
</div>

<?php if (empty($categories)): ?>
<div class="adm-card">
    <div class="adm-card-body">
        <div class="adm-empty-sm" style="padding: var(--space-8);"><?= icon('grid', 32) ?><p>Henüz kategori eklenmemiş.</p></div>
    </div>
</div>
<?php else: ?>

<!-- Desktop Table -->
<div class="adm-card adm-cat-desktop">
    <div class="adm-card-body" style="padding: 0;">
        <table class="adm-table">
            <thead>
                <tr>
                    <th>İkon</th>
                    <th>Kategori Adı</th>
                    <th>Slug</th>
                    <th>Paket</th>
                    <th>SEO</th>
                    <th>Durum</th>
                    <th>Sıra</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($categories as $cat): ?>
                <tr>
                    <td>
                        <div class="adm-icon-cell"><?= icon($cat['icon_key'] ?? 'package', 18) ?></div>
                    </td>
                    <td class="font-semibold"><?= e($cat['name']) ?></td>
                    <td class="text-xs text-secondary"><?= e($cat['slug']) ?></td>
                    <td>
                        <span class="adm-count-badge"><?= $cat['package_count'] ?></span>
                    </td>
                    <td>
                        <?php $seoScore = $cat['seo_score'] ?? 0; ?>
                        <span class="adm-seo-pill <?= $seoScore >= 80 ? 'seo-good' : ($seoScore >= 50 ? 'seo-ok' : 'seo-bad') ?>"><?= $seoScore ?></span>
                    </td>
                    <td>
                        <span class="status-badge <?= $cat['status'] === 'active' ? 'success' : 'default' ?>"><?= $cat['status'] === 'active' ? 'Aktif' : 'Pasif' ?></span>
                    </td>
                    <td class="text-sm text-secondary"><?= $cat['sort_order'] ?></td>
                    <td>
                        <div class="adm-actions">
                            <a href="/admin/kategori/<?= $cat['id'] ?>/duzenle" class="adm-action-btn" title="Düzenle"><?= icon('edit', 14) ?></a>
                            <form method="POST" action="/admin/kategori/<?= $cat['id'] ?>/sil" onsubmit="return confirm('Bu kategoriyi silmek istediğinize emin misiniz?')"><?= csrfField() ?><button class="adm-action-btn adm-action-danger" title="Sil"><?= icon('trash', 14) ?></button></form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Mobile Cards -->
<div class="adm-cat-mobile">
    <?php foreach ($categories as $cat): ?>
    <div class="adm-order-card-m">
        <div class="adm-order-card-m-top">
            <div class="flex-center gap-2">
                <div class="adm-icon-cell"><?= icon($cat['icon_key'] ?? 'package', 16) ?></div>
                <span class="font-semibold"><?= e($cat['name']) ?></span>
            </div>
            <span class="status-badge <?= $cat['status'] === 'active' ? 'success' : 'default' ?>"><?= $cat['status'] === 'active' ? 'Aktif' : 'Pasif' ?></span>
        </div>
        <div class="adm-order-card-m-body">
            <div class="adm-order-card-m-row">
                <span class="adm-order-card-m-label">Slug</span>
                <span class="text-xs text-secondary"><?= e($cat['slug']) ?></span>
            </div>
            <div class="adm-order-card-m-row">
                <span class="adm-order-card-m-label">Paket Sayısı</span>
                <span class="adm-count-badge"><?= $cat['package_count'] ?></span>
            </div>
            <div class="adm-order-card-m-row">
                <span class="adm-order-card-m-label">SEO</span>
                <?php $seoScore = $cat['seo_score'] ?? 0; ?>
                <span class="adm-seo-pill <?= $seoScore >= 80 ? 'seo-good' : ($seoScore >= 50 ? 'seo-ok' : 'seo-bad') ?>"><?= $seoScore ?></span>
            </div>
            <div class="adm-order-card-m-row">
                <span class="adm-order-card-m-label">Sıra</span>
                <span class="text-sm"><?= $cat['sort_order'] ?></span>
            </div>
        </div>
        <div class="adm-card-m-actions">
            <a href="/admin/kategori/<?= $cat['id'] ?>/duzenle" class="adm-order-card-m-action" style="border-right: 1px solid var(--color-border);"><?= icon('edit', 14) ?> Düzenle</a>
            <form method="POST" action="/admin/kategori/<?= $cat['id'] ?>/sil" onsubmit="return confirm('Bu kategoriyi silmek istediğinize emin misiniz?')" style="flex:1;margin:0;">
                <?= csrfField() ?>
                <button class="adm-order-card-m-action" style="width:100%;color:var(--color-red);border:none;background:none;cursor:pointer;font-family:var(--font-family);"><?= icon('trash', 14) ?> Sil</button>
            </form>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>
