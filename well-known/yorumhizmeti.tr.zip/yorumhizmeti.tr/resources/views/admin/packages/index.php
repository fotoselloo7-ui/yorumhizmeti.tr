<div class="adm-page-top">
    <div>
        <h2><?= icon('package', 24) ?> Paketler</h2>
        <p class="text-sm text-secondary">Tüm hizmet paketlerinizi yönetin.</p>
    </div>
    <div class="adm-page-top-badges">
        <a href="/admin/import" class="btn btn-outline btn-sm"><?= icon('upload', 14) ?> Excel/CSV İçe Aktar</a>
        <a href="/admin/paket/ekle" class="btn btn-primary btn-sm"><?= icon('plus', 16) ?> Paket Ekle</a>
    </div>
</div>

<?php if (empty($packages)): ?>
<div class="adm-card">
    <div class="adm-card-body">
        <div class="adm-empty-sm" style="padding: var(--space-8);"><?= icon('package', 32) ?><p>Henüz paket eklenmemiş.</p></div>
    </div>
</div>
<?php else: ?>

<!-- Desktop Table -->
<div class="adm-card adm-pkg-desktop">
    <div class="adm-card-body" style="padding: 0;">
        <table class="adm-table">
            <thead>
                <tr>
                    <th>Paket Adı</th>
                    <th>Kategori</th>
                    <th>Fiyat</th>
                    <th>İnd. Fiyat</th>
                    <th>Teslimat</th>
                    <th>Adet</th>
                    <th>SEO</th>
                    <th>Durum</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($packages as $pkg): ?>
                <tr>
                    <td>
                        <div class="adm-pkg-name">
                            <span class="font-semibold"><?= e($pkg['name']) ?></span>
                            <?php if (!empty($pkg['is_featured'])): ?>
                            <span class="adm-featured-badge"><?= icon('star', 10) ?> Öne Çıkan</span>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td>
                        <span class="adm-cat-badge"><?= icon($pkg['icon_key'] ?? 'package', 12) ?> <?= e($pkg['category_name'] ?? '-') ?></span>
                    </td>
                    <td class="font-semibold"><?= money($pkg['price']) ?></td>
                    <td>
                        <?php if ($pkg['discount_price']): ?>
                        <span class="font-semibold" style="color: var(--color-green);"><?= money($pkg['discount_price']) ?></span>
                        <?php else: ?>
                        <span class="text-secondary">-</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-sm"><?= e($pkg['delivery_time'] ?? '-') ?></td>
                    <td class="text-xs text-secondary"><?= $pkg['min_quantity'] ?>-<?= $pkg['max_quantity'] ?></td>
                    <td>
                        <?php $seoScore = $pkg['seo_score'] ?? 0; ?>
                        <span class="adm-seo-pill <?= $seoScore >= 80 ? 'seo-good' : ($seoScore >= 50 ? 'seo-ok' : 'seo-bad') ?>"><?= $seoScore ?></span>
                    </td>
                    <td>
                        <span class="status-badge <?= $pkg['status'] === 'active' ? 'success' : 'default' ?>"><?= $pkg['status'] === 'active' ? 'Aktif' : 'Pasif' ?></span>
                    </td>
                    <td>
                        <div class="adm-actions">
                            <a href="/admin/paket/<?= $pkg['id'] ?>/alanlar" class="adm-action-btn" title="Alanlar"><?= icon('list', 14) ?></a>
                            <a href="/admin/paket/<?= $pkg['id'] ?>/duzenle" class="adm-action-btn" title="Düzenle"><?= icon('edit', 14) ?></a>
                            <form method="POST" action="/admin/paket/<?= $pkg['id'] ?>/sil" onsubmit="return confirm('Bu paketi silmek istediğinize emin misiniz?')"><?= csrfField() ?><button class="adm-action-btn adm-action-danger" title="Sil"><?= icon('trash', 14) ?></button></form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Mobile Cards -->
<div class="adm-pkg-mobile">
    <?php foreach ($packages as $pkg): ?>
    <div class="adm-order-card-m">
        <div class="adm-order-card-m-top">
            <div>
                <span class="font-semibold"><?= e($pkg['name']) ?></span>
                <?php if (!empty($pkg['is_featured'])): ?>
                <span class="adm-featured-badge"><?= icon('star', 10) ?></span>
                <?php endif; ?>
            </div>
            <span class="status-badge <?= $pkg['status'] === 'active' ? 'success' : 'default' ?>"><?= $pkg['status'] === 'active' ? 'Aktif' : 'Pasif' ?></span>
        </div>
        <div class="adm-order-card-m-body">
            <div class="adm-order-card-m-row">
                <span class="adm-order-card-m-label">Kategori</span>
                <span class="text-sm"><?= e($pkg['category_name'] ?? '-') ?></span>
            </div>
            <div class="adm-order-card-m-row">
                <span class="adm-order-card-m-label">Fiyat</span>
                <div>
                    <strong><?= money($pkg['price']) ?></strong>
                    <?php if ($pkg['discount_price']): ?>
                    <span class="text-xs" style="color: var(--color-green);"> / <?= money($pkg['discount_price']) ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="adm-order-card-m-row">
                <span class="adm-order-card-m-label">Teslimat</span>
                <span class="text-sm"><?= e($pkg['delivery_time'] ?? '-') ?></span>
            </div>
            <div class="adm-order-card-m-row">
                <span class="adm-order-card-m-label">SEO</span>
                <?php $seoScore = $pkg['seo_score'] ?? 0; ?>
                <span class="adm-seo-pill <?= $seoScore >= 80 ? 'seo-good' : ($seoScore >= 50 ? 'seo-ok' : 'seo-bad') ?>"><?= $seoScore ?></span>
            </div>
        </div>
        <div class="adm-card-m-actions">
            <a href="/admin/paket/<?= $pkg['id'] ?>/alanlar" class="adm-order-card-m-action" style="border-right: 1px solid var(--color-border);"><?= icon('list', 14) ?> Alanlar</a>
            <a href="/admin/paket/<?= $pkg['id'] ?>/duzenle" class="adm-order-card-m-action" style="border-right: 1px solid var(--color-border);"><?= icon('edit', 14) ?> Düzenle</a>
            <form method="POST" action="/admin/paket/<?= $pkg['id'] ?>/sil" onsubmit="return confirm('Bu paketi silmek istediğinize emin misiniz?')" style="flex:1;margin:0;"><?= csrfField() ?><button class="adm-order-card-m-action" style="width:100%;color:var(--color-red);border:none;background:none;cursor:pointer;font-family:var(--font-family);"><?= icon('trash', 14) ?> Sil</button></form>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>
