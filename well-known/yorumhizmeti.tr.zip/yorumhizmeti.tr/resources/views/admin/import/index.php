<div class="adm-page-top">
    <div class="adm-page-top-left">
        <a href="/admin/paketler" class="btn btn-outline btn-sm"><?= icon('arrow-left', 14) ?> Paketlere Dön</a>
        <h2><?= icon('upload', 24) ?> CSV / Excel İçe Aktar</h2>
    </div>
</div>

<div class="adm-import-grid">
    <!-- Upload Form -->
    <div class="adm-card">
        <div class="adm-card-header"><h3><?= icon('upload', 18) ?> Dosya Yükle</h3></div>
        <div class="adm-card-body">
            <form method="POST" action="/admin/import/islem" enctype="multipart/form-data">
                <?= csrfField() ?>
                <div class="adm-upload-zone" id="uploadZone" onclick="document.getElementById('csvFileInput').click()">
                    <div class="adm-upload-icon"><?= icon('upload', 32) ?></div>
                    <div class="adm-upload-text">
                        <strong>Dosya seçin veya sürükleyin</strong>
                        <span class="text-xs text-secondary">Kabul edilen formatlar: .csv, .txt</span>
                    </div>
                    <div class="adm-upload-filename" id="uploadFileName" style="display:none;"></div>
                    <input type="file" name="csv_file" id="csvFileInput" accept=".csv,.txt" required style="display:none;" onchange="showFileName(this)">
                </div>
                <div class="adm-featured-check" style="margin-top: var(--space-4);">
                    <label>
                        <input type="checkbox" name="update_duplicate" value="1">
                        <span>Aynı slug varsa güncelle</span>
                    </label>
                    <div class="form-hint">İşaretlerseniz mevcut paketler güncellenir, yeni eklenmez.</div>
                </div>
                <button type="submit" class="btn btn-primary btn-block" style="margin-top: var(--space-4);"><?= icon('upload', 16) ?> İçe Aktar</button>
            </form>
        </div>
    </div>

    <!-- Instructions -->
    <div class="adm-card">
        <div class="adm-card-header"><h3><?= icon('info', 18) ?> Kullanım Kılavuzu</h3></div>
        <div class="adm-card-body">
            <div class="adm-import-info">
                <h4>Zorunlu Sütunlar</h4>
                <div class="adm-import-cols">
                    <div class="adm-import-col adm-col-required"><code>name</code> <span>Paket adı</span></div>
                    <div class="adm-import-col adm-col-required"><code>category_id</code> <span>Kategori ID</span></div>
                    <div class="adm-import-col adm-col-required"><code>price</code> <span>Fiyat</span></div>
                </div>

                <h4 style="margin-top: var(--space-5);">Opsiyonel Sütunlar</h4>
                <div class="adm-import-cols">
                    <div class="adm-import-col"><code>discount_price</code> <span>İndirimli fiyat</span></div>
                    <div class="adm-import-col"><code>short_description</code> <span>Kısa açıklama</span></div>
                    <div class="adm-import-col"><code>description</code> <span>Detay açıklama</span></div>
                    <div class="adm-import-col"><code>delivery_time</code> <span>Teslim süresi</span></div>
                    <div class="adm-import-col"><code>min_quantity</code> <span>Min adet</span></div>
                    <div class="adm-import-col"><code>max_quantity</code> <span>Max adet</span></div>
                    <div class="adm-import-col"><code>status</code> <span>active / inactive</span></div>
                </div>

                <div class="adm-import-note" style="margin-top: var(--space-5);">
                    <?= icon('alert-circle', 16) ?>
                    <div>
                        <strong>Önemli</strong>
                        <ul style="margin-top: 4px; padding-left: var(--space-4); list-style: disc;">
                            <li>CSV dosyası UTF-8 formatında olmalıdır.</li>
                            <li>İlk satır sütun başlıkları olmalıdır.</li>
                            <li>Slug otomatik üretilir (isimden).</li>
                            <li>category_id mevcut bir kategori ID'si olmalıdır.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function showFileName(input) {
    var zone = document.getElementById('uploadZone');
    var nameEl = document.getElementById('uploadFileName');
    if (input.files && input.files[0]) {
        nameEl.textContent = input.files[0].name;
        nameEl.style.display = 'block';
        zone.classList.add('has-file');
    }
}
</script>
