<div class="cat-page-wrapper">
    <!-- Hero Section -->
    <section class="cat-hero section-dark pb-0">
        <div class="container">
            <div class="breadcrumb" style="margin-bottom: var(--space-4);">
                <a href="/">Ana Sayfa</a> <span class="separator">/</span>
                <a href="/kategoriler">Hizmetler</a> <span class="separator">/</span>
                <span><?= e($category['name']) ?></span>
            </div>
            
            <div class="cat-hero-content">
                <div class="cat-hero-icon">
                    <?= icon($category['icon_key'] ?? 'package', 48) ?>
                </div>
                <div class="cat-hero-text">
                    <h1><?= e($category['name']) ?></h1>
                    <?php if ($category['description']): ?>
                    <p><?= e($category['description']) ?></p>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="cat-trust-badges">
                <div class="trust-badge"><?= icon('shield', 16) ?> Güvenli Ödeme</div>
                <div class="trust-badge"><?= icon('zap', 16) ?> Hızlı Teslimat</div>
                <div class="trust-badge"><?= icon('search', 16) ?> Sipariş Takibi</div>
                <div class="trust-badge"><?= icon('message-circle', 16) ?> 7/24 Destek</div>
            </div>
        </div>
    </section>

    <!-- Main Content Area -->
    <section class="section bg-light">
        <div class="container">
            <!-- Filter & Sort Bar -->
            <div class="cat-filters">
                <?php if (!empty($subCategories)): ?>
                <div class="cat-chip-scroll">
                    <div class="cat-chip-list">
                        <a href="?<?= http_build_query(array_merge($_GET, ['alt' => ''])) ?>" class="cat-chip <?= empty($altSlug) ? 'active' : '' ?>">Tümü</a>
                        <?php foreach ($subCategories as $sub): ?>
                        <a href="?<?= http_build_query(array_merge($_GET, ['alt' => $sub['slug']])) ?>" class="cat-chip <?= $altSlug === $sub['slug'] ? 'active' : '' ?>">
                            <?= e($sub['name']) ?>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <div class="cat-search-sort">
                    <form action="" method="GET" class="cat-search-form">
                        <?php if ($altSlug): ?><input type="hidden" name="alt" value="<?= e($altSlug) ?>"><?php endif; ?>
                        <?php if ($currentSort): ?><input type="hidden" name="sort" value="<?= e($currentSort) ?>"><?php endif; ?>
                        <div class="search-input-wrapper">
                            <?= icon('search', 16) ?>
                            <input type="text" name="q" class="form-control form-control-sm" placeholder="Paket ara..." value="<?= e($searchQuery) ?>">
                            <?php if ($searchQuery): ?>
                                <a href="?<?= http_build_query(array_merge($_GET, ['q' => ''])) ?>" class="search-clear"><?= icon('x', 14) ?></a>
                            <?php endif; ?>
                        </div>
                    </form>
                    
                    <form action="" method="GET" class="cat-sort-form">
                        <?php if ($altSlug): ?><input type="hidden" name="alt" value="<?= e($altSlug) ?>"><?php endif; ?>
                        <?php if ($searchQuery): ?><input type="hidden" name="q" value="<?= e($searchQuery) ?>"><?php endif; ?>
                        <select name="sort" class="form-control form-control-sm" onchange="this.form.submit()">
                            <option value="recommended" <?= $currentSort === 'recommended' ? 'selected' : '' ?>>Önerilen</option>
                            <option value="price_asc" <?= $currentSort === 'price_asc' ? 'selected' : '' ?>>En düşük fiyat</option>
                            <option value="price_desc" <?= $currentSort === 'price_desc' ? 'selected' : '' ?>>En yüksek fiyat</option>
                            <option value="featured" <?= $currentSort === 'featured' ? 'selected' : '' ?>>Popüler / Öne Çıkan</option>
                        </select>
                    </form>
                </div>
            </div>

            <!-- Package Grid -->
            <?php if (!empty($packages)): ?>
            <div class="pkg-grid">
                <?php foreach ($packages as $pkg): ?>
                <div class="pkg-card <?= $pkg['is_featured'] ? 'pkg-featured' : '' ?>">
                    <?php if ($pkg['is_featured']): ?>
                    <div class="pkg-badge featured-badge"><?= icon('star', 12) ?> Öne Çıkan</div>
                    <?php elseif ($pkg['badge']): ?>
                    <div class="pkg-badge popular-badge"><?= e($pkg['badge']) ?></div>
                    <?php endif; ?>
                    
                    <div class="pkg-card-top">
                        <div class="pkg-icon"><?= icon($pkg['icon_key'] ?? $category['icon_key'] ?? 'package', 24) ?></div>
                        <div class="pkg-cat-label"><?= e($pkg['category_name'] ?? $category['name']) ?></div>
                    </div>
                    
                    <h3 class="pkg-title"><a href="/paket/<?= e($pkg['slug']) ?>"><?= e($pkg['name']) ?></a></h3>
                    <p class="pkg-desc"><?= e(excerpt($pkg['short_description'] ?? '', 80)) ?></p>
                    
                    <div class="pkg-price-row">
                        <div class="pkg-price">
                            <?php if ($pkg['discount_price'] && $pkg['discount_price'] < $pkg['price']): ?>
                                <span class="pkg-price-new"><?= money($pkg['discount_price']) ?></span>
                                <span class="pkg-price-old"><?= money($pkg['price']) ?></span>
                            <?php else: ?>
                                <span class="pkg-price-new"><?= money($pkg['price']) ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="pkg-meta">
                        <?php if ($pkg['delivery_time']): ?>
                        <div class="pkg-meta-item"><?= icon('clock', 14) ?> <?= e($pkg['delivery_time']) ?></div>
                        <?php endif; ?>
                        <div class="pkg-meta-item"><?= icon('hash', 14) ?> <?= $pkg['min_quantity'] ?> - <?= $pkg['max_quantity'] ?> Adet</div>
                    </div>
                    
                    <div class="pkg-actions">
                        <a href="/paket/<?= e($pkg['slug']) ?>" class="btn btn-outline btn-block">Detayları Gör</a>
                        <form method="POST" action="/sepet/ekle" class="pkg-add-cart">
                            <?= csrfField() ?>
                            <input type="hidden" name="package_id" value="<?= $pkg['id'] ?>">
                            <input type="hidden" name="quantity" value="<?= $pkg['min_quantity'] ?>">
                            <button type="submit" class="btn btn-primary btn-icon" title="Sepete Ekle"><?= icon('shopping-cart', 16) ?></button>
                        </form>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="empty-state modern-empty">
                <?= icon('search', 48) ?>
                <?php if ($searchQuery): ?>
                <h3>Aramanıza uygun paket bulunamadı</h3>
                <p>"<?= e($searchQuery) ?>" araması için sonuç yok. Lütfen başka kelimeler deneyin.</p>
                <a href="?<?= http_build_query(array_merge($_GET, ['q' => ''])) ?>" class="btn btn-outline" style="margin-top: 1rem;">Aramayı Temizle</a>
                <?php else: ?>
                <h3>Bu kategoride henüz paket bulunmuyor</h3>
                <p>Şu an için listelenecek paket bulunmamaktadır.</p>
                <?php if ($altSlug): ?>
                <a href="?<?= http_build_query(array_merge($_GET, ['alt' => ''])) ?>" class="btn btn-outline" style="margin-top: 1rem;">Tüm Paketleri Görüntüle</a>
                <?php endif; ?>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- SEO Area (Only show on main category if no subcategory selected, or if SEO text is needed) -->
    <!-- Assuming the category description is already at top, we don't have a separate HTML content field in DB for categories right now, but if there was, it would go here. -->
</div>
