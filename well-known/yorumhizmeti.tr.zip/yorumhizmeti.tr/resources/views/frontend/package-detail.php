<?php
$lowerName = strtolower($package['name'] . ' ' . ($package['category_name'] ?? ''));
$platformIcon = 'box';
$platformColor = 'var(--color-blue)';

if (strpos($lowerName, 'instagram') !== false) { $platformIcon = 'instagram'; $platformColor = '#E1306C'; }
elseif (strpos($lowerName, 'tiktok') !== false) { $platformIcon = 'tiktok'; $platformColor = '#000000'; }
elseif (strpos($lowerName, 'youtube') !== false) { $platformIcon = 'youtube'; $platformColor = '#FF0000'; }
elseif (strpos($lowerName, 'twitter') !== false || strpos($lowerName, 'x') !== false) { $platformIcon = 'twitter'; $platformColor = '#1DA1F2'; }
elseif (strpos($lowerName, 'facebook') !== false) { $platformIcon = 'facebook'; $platformColor = '#1877F2'; }
elseif (strpos($lowerName, 'google') !== false || strpos($lowerName, 'seo') !== false) { $platformIcon = 'google'; $platformColor = '#4285F4'; }
elseif (strpos($lowerName, 'spotify') !== false) { $platformIcon = 'music'; $platformColor = '#1DB954'; }
elseif (strpos($lowerName, 'twitch') !== false) { $platformIcon = 'video'; $platformColor = '#9146FF'; }
elseif (strpos($lowerName, 'telegram') !== false) { $platformIcon = 'send'; $platformColor = '#0088cc'; }
?>
<div class="breadcrumb container" style="padding-top: var(--space-4);">
    <a href="/"><?= icon('home', 14) ?> Ana Sayfa</a> <span class="separator">/</span>
    <a href="/kategori/<?= e($package['category_slug'] ?? '') ?>"><?= e($package['category_name'] ?? 'Hizmetler') ?></a> <span class="separator">/</span>
    <span style="color: var(--color-text); font-weight: 500;"><?= e($package['name']) ?></span>
</div>

<section class="section" style="padding-top: var(--space-6);">
    <div class="container">
        <div class="package-detail-layout">
            
            <!-- Sol: İçerik -->
            <div class="package-main-content">
                
                <!-- Hero Area -->
                <div class="package-hero card mb-6" style="border-top: 4px solid <?= $platformColor ?>;">
                    <div class="hero-flex" style="display: flex; gap: var(--space-5); align-items: flex-start;">
                        <div class="platform-icon-large" style="width: 72px; height: 72px; background: <?= $platformColor ?>15; color: <?= $platformColor ?>; border-radius: var(--radius-xl); display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                            <?= icon($platformIcon, 36) ?>
                        </div>
                        <div class="hero-text">
                            <?php if ($package['badge']): ?>
                                <span class="badge" style="background: <?= $platformColor ?>; color: #fff; margin-bottom: var(--space-3); border: none;"><?= e($package['badge']) ?></span>
                            <?php endif; ?>
                            <h1 style="font-size: var(--font-size-2xl); font-weight: 700; color: var(--color-text); margin-bottom: var(--space-3); line-height: 1.2;">
                                <?= e($package['name']) ?>
                            </h1>
                            <?php if ($package['short_description']): ?>
                                <p class="text-secondary" style="font-size: var(--font-size-base); line-height: 1.6;">
                                    <?= e($package['short_description']) ?>
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Detaylı Açıklama -->
                <div class="card mb-6">
                    <div class="card-header" style="border-bottom: 1px solid var(--color-border); padding-bottom: var(--space-4); margin-bottom: var(--space-4);">
                        <h2 class="card-title" style="display: flex; align-items: center; gap: var(--space-2); font-weight: 600; font-size: var(--font-size-lg);">
                            <?= icon('info', 20) ?> Paket Açıklaması
                        </h2>
                    </div>
                    <div class="blog-content" style="padding: 0; border: none;">
                        <?= $package['description'] ?: '<p class="text-secondary">Bu paket için henüz detaylı bir açıklama girilmemiştir.</p>' ?>
                    </div>
                </div>

                <!-- Resim varsa -->
                <?php if (!empty($package['image'])): ?>
                <div class="card mb-6" style="overflow: hidden; padding: 0;">
                    <img src="<?= e(upload_url($package['image'])) ?>" alt="<?= e($package['image_alt'] ?? $package['name']) ?>" style="width: 100%; height: auto; display: block;">
                </div>
                <?php endif; ?>

                <!-- SSS Fallback -->
                <div class="card mb-6">
                    <div class="card-header" style="border-bottom: 1px solid var(--color-border); padding-bottom: var(--space-4); margin-bottom: var(--space-4);">
                        <h2 class="card-title" style="display: flex; align-items: center; gap: var(--space-2); font-weight: 600; font-size: var(--font-size-lg);">
                            <?= icon('help-circle', 20) ?> Sıkça Sorulan Sorular
                        </h2>
                    </div>
                    <div class="faq-list">
                        <div class="faq-item">
                            <div class="faq-question">
                                <span class="font-semibold">Sipariş verdim, hizmet ne zaman tamamlanır?</span>
                                <?= icon('chevron-down', 16) ?>
                            </div>
                            <div class="faq-answer">
                                <p>Siparişiniz onaylandıktan sonra, hizmetimiz genellikle paket üzerinde belirtilen "Teslimat Süresi" içinde tamamlanır. Otomatik işlemler anında başlayabilirken, manuel inceleme gerektiren durumlarda bu süre biraz uzayabilir.</p>
                            </div>
                        </div>
                        <div class="faq-item">
                            <div class="faq-question">
                                <span class="font-semibold">Şifremi vermem gerekiyor mu?</span>
                                <?= icon('chevron-down', 16) ?>
                            </div>
                            <div class="faq-answer">
                                <p>Kesinlikle hayır! Sistemimizde sağlanan hizmetlerin hiçbirinde şifre veya giriş bilgisi talep edilmez. Sadece ilgili gönderi veya profil bağlantınızı (Link) iletmeniz yeterlidir.</p>
                            </div>
                        </div>
                        <div class="faq-item">
                            <div class="faq-question">
                                <span class="font-semibold">Ödeme işlemlerim güvende mi?</span>
                                <?= icon('chevron-down', 16) ?>
                            </div>
                            <div class="faq-answer">
                                <p>Evet, tamamen güvende. Sitemiz 256-bit SSL sertifikası ile korunmaktadır ve 3D Secure onaylı, lisanslı ödeme altyapıları (PayTR, iyzico) ile hizmet vermektedir.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sağ: Sticky Sipariş Kartı -->
            <div class="package-sidebar">
                <div class="card package-sticky-card" style="position: sticky; top: 90px;">
                    
                    <!-- Fiyat Gösterimi -->
                    <div class="package-price-box" style="margin-bottom: var(--space-5); text-align: center; padding-bottom: var(--space-4); border-bottom: 1px dashed var(--color-border);">
                        <?php if ($package['discount_price'] && $package['discount_price'] < $package['price']): ?>
                            <div class="original-price" style="text-decoration: line-through; color: var(--color-text-secondary); font-size: var(--font-size-base); margin-bottom: 4px;"><?= money($package['price']) ?></div>
                            <div class="current-price" style="color: var(--color-blue); font-size: 36px; font-weight: 800; line-height: 1;"><?= money($package['discount_price']) ?></div>
                        <?php else: ?>
                            <div class="current-price" style="color: var(--color-text); font-size: 36px; font-weight: 800; line-height: 1;"><?= money($package['price']) ?></div>
                        <?php endif; ?>
                    </div>

                    <!-- Teslimat & Özellikler -->
                    <div class="package-meta" style="margin-bottom: var(--space-5);">
                        <?php if ($package['delivery_time']): ?>
                        <div style="display: flex; align-items: center; gap: var(--space-3); margin-bottom: var(--space-3); color: var(--color-text);">
                            <span style="color: var(--color-green);"><?= icon('clock', 18) ?></span>
                            <span style="font-weight: 500;">Tahmini Teslimat:</span>
                            <span><?= e($package['delivery_time']) ?></span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($package['min_quantity'] || $package['max_quantity']): ?>
                        <div style="display: flex; align-items: center; gap: var(--space-3); margin-bottom: var(--space-3); color: var(--color-text);">
                            <span style="color: var(--color-blue);"><?= icon('bar-chart', 18) ?></span>
                            <span style="font-weight: 500;">Sipariş Limiti:</span>
                            <span><?= number_format($package['min_quantity']) ?> - <?= number_format($package['max_quantity']) ?> adet</span>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Satın Alma Formu -->
                    <form id="packageForm" method="POST" action="/sepet/ekle">
                        <?= csrfField() ?>
                        <input type="hidden" name="package_id" value="<?= $package['id'] ?>">

                        <?php if (!empty($fields)): ?>
                            <div class="package-dynamic-fields" style="background: var(--color-bg); padding: var(--space-4); border-radius: var(--radius-md); margin-bottom: var(--space-5);">
                                <?php foreach ($fields as $field): ?>
                                <div class="form-group" style="margin-bottom: var(--space-3);">
                                    <label style="font-size: var(--font-size-sm); font-weight: 500; display: block; margin-bottom: 6px;">
                                        <?= e($field['field_label']) ?> <?= $field['is_required'] ? '<span class="text-danger">*</span>' : '' ?>
                                    </label>
                                    <?php if ($field['field_type'] === 'textarea'): ?>
                                        <textarea name="field_<?= $package['id'] ?>_<?= e($field['field_key']) ?>" class="form-control" placeholder="<?= e($field['placeholder'] ?? '') ?>" <?= $field['is_required'] ? 'required' : '' ?> rows="2"></textarea>
                                    <?php elseif ($field['field_type'] === 'select'): ?>
                                        <select name="field_<?= $package['id'] ?>_<?= e($field['field_key']) ?>" class="form-control" <?= $field['is_required'] ? 'required' : '' ?>>
                                            <option value="">Seçiniz</option>
                                            <?php foreach(explode(',', $field['options']??'') as $opt) { $opt=trim($opt); if($opt) echo "<option value='".e($opt)."'>".e($opt)."</option>"; } ?>
                                        </select>
                                    <?php else: ?>
                                        <input type="<?= $field['field_type']==='url'?'url':'text' ?>" name="field_<?= $package['id'] ?>_<?= e($field['field_key']) ?>" class="form-control" placeholder="<?= e($field['placeholder'] ?? '') ?>" <?= $field['is_required'] ? 'required' : '' ?>>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>

                        <?php if ($package['max_quantity'] > 1): ?>
                        <div class="form-group">
                            <label style="font-size: var(--font-size-sm); font-weight: 500;">Sipariş Adedi</label>
                            <input type="number" name="quantity" class="form-control" style="font-size: 16px; font-weight: 600;" value="<?= $package['min_quantity'] ?>" min="<?= $package['min_quantity'] ?>" max="<?= $package['max_quantity'] ?>">
                        </div>
                        <?php endif; ?>

                        <!-- Aksiyon Butonları -->
                        <div style="display: flex; flex-direction: column; gap: var(--space-3); margin-top: var(--space-5);">
                            <button type="submit" class="btn btn-primary btn-lg" style="width: 100%; justify-content: center; font-weight: 600;">
                                <?= icon('shopping-cart', 18) ?> Sepete Ekle
                            </button>
                            <button type="button" class="btn btn-success btn-lg" style="width: 100%; justify-content: center; font-weight: 600;" onclick="buyNow()">
                                <?= icon('zap', 18) ?> Hemen Satın Al
                            </button>
                            <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', setting('site_whatsapp') ?? '') ?>" target="_blank" class="btn btn-light" style="width: 100%; justify-content: center; border: 1px solid var(--color-border); font-weight: 500;">
                                <?= icon('message-circle', 18) ?> WhatsApp'tan Sor
                            </a>
                        </div>
                    </form>

                    <!-- Güven Kutusu -->
                    <div class="trust-box" style="margin-top: var(--space-6); padding-top: var(--space-5); border-top: 1px solid var(--color-border);">
                        <div style="display: flex; align-items: center; gap: var(--space-3); margin-bottom: var(--space-3);">
                            <div style="width: 32px; height: 32px; border-radius: 50%; background: var(--color-soft-green); color: var(--color-green); display: flex; align-items: center; justify-content: center; flex-shrink:0;">
                                <?= icon('shield', 16) ?>
                            </div>
                            <div>
                                <div style="font-size: var(--font-size-sm); font-weight: 600;">Güvenli Alışveriş</div>
                                <div style="font-size: 11px; color: var(--color-text-secondary);">256-bit SSL Şifreleme</div>
                            </div>
                        </div>
                        <div style="display: flex; align-items: center; gap: var(--space-3); margin-bottom: var(--space-3);">
                            <div style="width: 32px; height: 32px; border-radius: 50%; background: var(--color-soft-blue); color: var(--color-blue); display: flex; align-items: center; justify-content: center; flex-shrink:0;">
                                <?= icon('headphones', 16) ?>
                            </div>
                            <div>
                                <div style="font-size: var(--font-size-sm); font-weight: 600;">7/24 Kesintisiz Destek</div>
                                <div style="font-size: 11px; color: var(--color-text-secondary);">Taleplerinize anında yanıt</div>
                            </div>
                        </div>
                        <div style="display: flex; align-items: center; gap: var(--space-3);">
                            <div style="width: 32px; height: 32px; border-radius: 50%; background: var(--color-soft-amber); color: var(--color-amber); display: flex; align-items: center; justify-content: center; flex-shrink:0;">
                                <?= icon('truck', 16) ?>
                            </div>
                            <div>
                                <div style="font-size: var(--font-size-sm); font-weight: 600;">Sipariş Takibi</div>
                                <div style="font-size: 11px; color: var(--color-text-secondary);">Anlık durum bildirimi</div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            
        </div> <!-- /.package-detail-layout -->

        <!-- Benzer Paketler -->
        <?php if (!empty($relatedPackages)): ?>
        <div style="margin-top: var(--space-12); padding-top: var(--space-8); border-top: 1px solid var(--color-border);">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--space-6);">
                <h2 style="font-size: var(--font-size-xl); font-weight: 700; color: var(--color-text);">İlgili Paketler</h2>
                <a href="/kategori/<?= e($package['category_slug'] ?? '') ?>" class="btn btn-light btn-sm">Tümünü Gör <?= icon('arrow-right', 14) ?></a>
            </div>
            <div class="package-grid">
                <?php foreach ($relatedPackages as $rp): ?>
                    <?php
                    // İlgili paketler için dinamik ikon (Ana sayfadaki mantıkla aynı)
                    $rpIcon = 'box';
                    $rpLower = strtolower($rp['name'] . ' ' . ($package['category_name'] ?? ''));
                    if (strpos($rpLower, 'instagram') !== false) $rpIcon = 'instagram';
                    elseif (strpos($rpLower, 'tiktok') !== false) $rpIcon = 'tiktok';
                    elseif (strpos($rpLower, 'youtube') !== false) $rpIcon = 'youtube';
                    elseif (strpos($rpLower, 'twitter') !== false || strpos($rpLower, 'x') !== false) $rpIcon = 'twitter';
                    elseif (strpos($rpLower, 'facebook') !== false) $rpIcon = 'facebook';
                    elseif (strpos($rpLower, 'google') !== false || strpos($rpLower, 'seo') !== false) $rpIcon = 'google';
                    elseif (strpos($rpLower, 'spotify') !== false) $rpIcon = 'music';
                    elseif (strpos($rpLower, 'twitch') !== false) $rpIcon = 'video';
                    elseif (strpos($rpLower, 'telegram') !== false) $rpIcon = 'send';
                    ?>
                    <div class="package-card" style="display: flex; flex-direction: column; background: var(--color-card); border: 1px solid var(--color-border); border-radius: var(--radius-2xl); padding: var(--space-6); transition: var(--transition);">
                        <div class="package-icon" style="width: 48px; height: 48px; background: var(--color-soft-blue); color: var(--color-blue); border-radius: var(--radius-xl); display: flex; align-items: center; justify-content: center; margin-bottom: var(--space-4);">
                            <?= icon($rpIcon, 24) ?>
                        </div>
                        <h3 style="font-size: var(--font-size-lg); font-weight: 600; margin-bottom: var(--space-2);"><a href="/paket/<?= e($rp['slug']) ?>" style="color: inherit; text-decoration: none;"><?= e($rp['name']) ?></a></h3>
                        <p style="color: var(--color-text-secondary); font-size: var(--font-size-sm); margin-bottom: var(--space-5); flex: 1;">
                            <?= e(excerpt($rp['short_description'] ?? '', 80)) ?>
                        </p>
                        <div style="display: flex; align-items: center; justify-content: space-between; border-top: 1px solid var(--color-border); padding-top: var(--space-4);">
                            <div>
                                <?php $rpPrice = ($rp['discount_price'] && $rp['discount_price'] < $rp['price']) ? $rp['discount_price'] : $rp['price']; ?>
                                <div style="font-size: var(--font-size-xl); font-weight: 700; color: var(--color-blue);"><?= money($rpPrice) ?></div>
                            </div>
                            <a href="/paket/<?= e($rp['slug']) ?>" class="btn btn-light btn-icon" aria-label="Paketi İncele">
                                <?= icon('arrow-right', 18) ?>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

    </div>
</section>

<!-- Satın Alma JS Mantığı -->
<script>
function extractDynamicFields(form) {
    const dynamicFields = {};
    const formData = new FormData(form);
    for (let [key, value] of formData.entries()) {
        if (key.startsWith('field_')) {
            dynamicFields[key] = value;
        }
    }
    return dynamicFields;
}

function buyNow() {
    const form = document.getElementById('packageForm');
    if (!form.reportValidity()) return;
    
    // Formdaki alanları sessionStorage'a yaz
    const dynamicFields = extractDynamicFields(form);
    if (Object.keys(dynamicFields).length > 0) {
        sessionStorage.setItem('prefill_fields', JSON.stringify(dynamicFields));
    }

    // Yükleniyor efekti
    const btn = form.querySelector('.btn-success');
    btn.innerHTML = '<span style="width:16px;height:16px;border:2px solid #fff;border-bottom-color:transparent;border-radius:50%;display:inline-block;animation:spin 1s linear infinite;margin-right:8px;"></span> Yönlendiriliyor...';
    btn.disabled = true;

    // AJAX ile sepete ekle ve ödemeye geç
    fetch(form.action, {
        method: 'POST',
        body: new FormData(form),
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    }).then(() => {
        window.location.href = '/odeme';
    }).catch(() => {
        window.location.href = '/odeme';
    });
}

// Normal Sepete Ekle
document.getElementById('packageForm').addEventListener('submit', function() {
    const dynamicFields = extractDynamicFields(this);
    if (Object.keys(dynamicFields).length > 0) {
        sessionStorage.setItem('prefill_fields', JSON.stringify(dynamicFields));
    }
});
</script>

<style>
@keyframes spin { 100% { transform: rotate(360deg); } }
</style>
