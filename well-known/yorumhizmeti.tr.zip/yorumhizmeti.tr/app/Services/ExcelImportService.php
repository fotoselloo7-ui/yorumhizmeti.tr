<?php
namespace App\Services;

use App\Core\Database;

class ExcelImportService
{
    public function importCsv(string $filePath, array $options = []): array
    {
        $db = Database::getInstance();
        $results = ['success' => 0, 'skipped' => 0, 'errors' => [], 'created_categories' => 0];

        if (!file_exists($filePath)) {
            $results['errors'][] = 'Dosya bulunamadı.';
            return $results;
        }

        $handle = fopen($filePath, 'r');
        if (!$handle) {
            $results['errors'][] = 'Dosya açılamadı.';
            return $results;
        }

        // İlk satır başlıklar
        $headers = fgetcsv($handle, 0, ',', '"');
        if (!$headers) {
            $results['errors'][] = 'Dosya başlıkları okunamadı.';
            fclose($handle);
            return $results;
        }

        $headers = array_map('trim', $headers);
        $rowNum = 1;

        while (($row = fgetcsv($handle, 0, ',', '"')) !== false) {
            $rowNum++;
            if (count($row) < count($headers)) {
                $results['errors'][] = "Satır {$rowNum}: Eksik kolon.";
                continue;
            }

            $data = array_combine($headers, $row);

            // Kategori kontrolü
            $categoryName = trim($data['category_name'] ?? '');
            $categorySlug = trim($data['category_slug'] ?? slugify($categoryName));
            $categoryId = null;

            if ($categoryName) {
                $existing = $db->fetch("SELECT id FROM categories WHERE slug = ?", [$categorySlug]);
                if ($existing) {
                    $categoryId = $existing['id'];
                } else {
                    // Kategori oluştur
                    $categoryId = $db->insert('categories', [
                        'name' => $categoryName,
                        'slug' => $categorySlug,
                        'icon_key' => trim($data['category_icon'] ?? 'package'),
                        'status' => 'active',
                    ]);
                    $results['created_categories']++;
                }
            }

            if (!$categoryId) {
                $results['errors'][] = "Satır {$rowNum}: Kategori bulunamadı veya oluşturulamadı.";
                continue;
            }

            $slug = trim($data['slug'] ?? slugify($data['package_name'] ?? ''));
            if (empty($slug)) {
                $results['errors'][] = "Satır {$rowNum}: Slug boş.";
                continue;
            }

            // Slug kontrolü
            $existingPkg = $db->fetch("SELECT id FROM packages WHERE slug = ?", [$slug]);

            $updateOnDuplicate = $options['update_on_duplicate'] ?? false;

            if ($existingPkg && !$updateOnDuplicate) {
                $results['skipped']++;
                continue;
            }

            $packageData = [
                'category_id' => $categoryId,
                'name' => trim($data['package_name'] ?? ''),
                'slug' => $slug,
                'short_description' => trim($data['short_description'] ?? ''),
                'description' => trim($data['description'] ?? ''),
                'image_alt' => trim($data['image_alt'] ?? ''),
                'price' => (float) ($data['price'] ?? 0),
                'discount_price' => !empty($data['discount_price']) ? (float) $data['discount_price'] : null,
                'delivery_time' => trim($data['delivery_time'] ?? ''),
                'min_quantity' => (int) ($data['min_quantity'] ?? 1),
                'max_quantity' => (int) ($data['max_quantity'] ?? 1),
                'badge' => trim($data['badge'] ?? '') ?: null,
                'status' => trim($data['status'] ?? 'active'),
                'sort_order' => (int) ($data['sort_order'] ?? 0),
                'seo_title' => trim($data['seo_title'] ?? ''),
                'seo_description' => trim($data['seo_description'] ?? ''),
                'seo_focus_keyword' => trim($data['seo_focus_keyword'] ?? ''),
            ];

            try {
                if ($existingPkg) {
                    $db->update('packages', $packageData, 'id = ?', [$existingPkg['id']]);
                } else {
                    $packageId = $db->insert('packages', $packageData);

                    // Dinamik alanlar
                    $requiredFields = trim($data['required_fields'] ?? '');
                    if ($requiredFields) {
                        $fields = explode(';', $requiredFields);
                        $sortOrder = 0;
                        foreach ($fields as $fieldDef) {
                            $parts = explode('|', trim($fieldDef));
                            if (count($parts) >= 2) {
                                $db->insert('package_fields', [
                                    'package_id' => $packageId,
                                    'field_key' => trim($parts[0]),
                                    'field_label' => trim($parts[1]),
                                    'field_type' => trim($parts[2] ?? 'text'),
                                    'is_required' => 1,
                                    'placeholder' => trim($parts[3] ?? ''),
                                    'sort_order' => $sortOrder++,
                                ]);
                            }
                        }
                    }
                }
                $results['success']++;
            } catch (\Exception $e) {
                $results['errors'][] = "Satır {$rowNum}: " . $e->getMessage();
            }
        }

        fclose($handle);
        return $results;
    }

    /**
     * CSV şablon indir
     */
    public function getTemplateHeaders(): array
    {
        return [
            'category_name', 'category_slug', 'category_icon',
            'package_name', 'slug', 'short_description', 'description',
            'image_alt', 'price', 'discount_price', 'delivery_time',
            'min_quantity', 'max_quantity', 'badge', 'status', 'sort_order',
            'seo_title', 'seo_description', 'seo_focus_keyword', 'required_fields'
        ];
    }
}
