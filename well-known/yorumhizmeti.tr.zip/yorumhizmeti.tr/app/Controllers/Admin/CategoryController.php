<?php
namespace App\Controllers\Admin;
use App\Core\Controller;
use App\Core\Csrf;
use App\Core\Upload;
use App\Services\SeoScoreService;

class CategoryController extends Controller
{
    public function index(): void
    {
        $categories = $this->db->fetchAll("SELECT c.*, (SELECT COUNT(*) FROM packages WHERE category_id = c.id) as package_count FROM categories c ORDER BY c.sort_order ASC");
        $this->renderAdmin('admin/categories/index', ['pageTitle' => 'Kategoriler', 'categories' => $categories]);
    }

    public function create(): void
    {
        $parents = $this->db->fetchAll("SELECT id, name FROM categories WHERE parent_id IS NULL ORDER BY name");
        $icons = \App\Services\IconService::list();
        $this->renderAdmin('admin/categories/form', ['pageTitle' => 'Kategori Ekle', 'category' => null, 'parents' => $parents, 'icons' => $icons]);
    }

    public function store(): void
    {
        Csrf::check();
        $data = $this->getCategoryData();

        if (!empty($_FILES['image']['name'])) {
            $data['image'] = Upload::image($_FILES['image'], 'categories');
        }

        $seo = new SeoScoreService();
        $score = $seo->calculate($data);
        $data['seo_score'] = $score['score'];

        $this->db->insert('categories', $data);
        logActivity('category_create', 'Kategori oluşturuldu: ' . $data['name']);
        flash('success', 'Kategori oluşturuldu.');
        redirect('/admin/kategoriler');
    }

    public function edit(string $id): void
    {
        $category = $this->db->fetch("SELECT * FROM categories WHERE id = ?", [(int) $id]);
        if (!$category) { redirect('/admin/kategoriler'); }

        $parents = $this->db->fetchAll("SELECT id, name FROM categories WHERE parent_id IS NULL AND id != ? ORDER BY name", [$id]);
        $icons = \App\Services\IconService::list();
        $seo = (new SeoScoreService())->calculate($category);

        $this->renderAdmin('admin/categories/form', [
            'pageTitle' => 'Kategori Düzenle',
            'category' => $category,
            'parents' => $parents,
            'icons' => $icons,
            'seoResult' => $seo,
        ]);
    }

    public function update(string $id): void
    {
        Csrf::check();
        $data = $this->getCategoryData();

        if (!empty($_FILES['image']['name'])) {
            $data['image'] = Upload::image($_FILES['image'], 'categories');
        }

        $seo = new SeoScoreService();
        $score = $seo->calculate($data);
        $data['seo_score'] = $score['score'];

        $this->db->update('categories', $data, 'id = ?', [(int) $id]);
        logActivity('category_update', 'Kategori güncellendi: ' . $data['name']);
        flash('success', 'Kategori güncellendi.');
        redirect('/admin/kategoriler');
    }

    public function delete(string $id): void
    {
        Csrf::check();
        $this->db->delete('categories', 'id = ?', [(int) $id]);
        logActivity('category_delete', 'Kategori silindi: ID ' . $id);
        flash('success', 'Kategori silindi.');
        redirect('/admin/kategoriler');
    }

    public function toggleStatus(string $id): void
    {
        Csrf::check();
        $cat = $this->db->fetch("SELECT status FROM categories WHERE id = ?", [(int) $id]);
        $newStatus = $cat['status'] === 'active' ? 'inactive' : 'active';
        $this->db->update('categories', ['status' => $newStatus], 'id = ?', [(int) $id]);
        flash('success', 'Durum güncellendi.');
        redirect('/admin/kategoriler');
    }

    private function getCategoryData(): array
    {
        return [
            'parent_id' => !empty($_POST['parent_id']) ? (int) $_POST['parent_id'] : null,
            'name' => trim($_POST['name'] ?? ''),
            'slug' => trim($_POST['slug'] ?? '') ?: slugify($_POST['name'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'image_alt' => trim($_POST['image_alt'] ?? ''),
            'icon_key' => $_POST['icon_key'] ?? 'package',
            'sort_order' => (int) ($_POST['sort_order'] ?? 0),
            'status' => $_POST['status'] ?? 'active',
            'seo_title' => trim($_POST['seo_title'] ?? ''),
            'seo_description' => trim($_POST['seo_description'] ?? ''),
            'seo_focus_keyword' => trim($_POST['seo_focus_keyword'] ?? ''),
            'canonical_url' => trim($_POST['canonical_url'] ?? ''),
            'og_title' => trim($_POST['og_title'] ?? ''),
            'og_description' => trim($_POST['og_description'] ?? ''),
        ];
    }
}
