<?php
namespace App\Controllers\Admin;
use App\Core\Controller;
use App\Core\Csrf;
use App\Core\Upload;
use App\Services\SeoScoreService;

class PackageController extends Controller
{
    public function index(): void
    {
        $packages = $this->db->fetchAll("SELECT p.*, c.name as category_name, c.icon_key FROM packages p LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.sort_order ASC, p.id DESC");
        $this->renderAdmin('admin/packages/index', ['pageTitle' => 'Paketler', 'packages' => $packages]);
    }

    public function create(): void
    {
        $categories = $this->db->fetchAll("SELECT id, name FROM categories WHERE status = 'active' ORDER BY name");
        $this->renderAdmin('admin/packages/form', ['pageTitle' => 'Paket Ekle', 'package' => null, 'categories' => $categories, 'fields' => []]);
    }

    public function store(): void
    {
        Csrf::check();
        $data = $this->getPackageData();
        if (!empty($_FILES['image']['name'])) { $data['image'] = Upload::image($_FILES['image'], 'packages'); }
        $data['seo_score'] = (new SeoScoreService())->calculate($data)['score'];

        $pkgId = $this->db->insert('packages', $data);
        logActivity('package_create', 'Paket oluşturuldu: ' . $data['name']);
        flash('success', 'Paket oluşturuldu.');
        redirect('/admin/paketler');
    }

    public function edit(string $id): void
    {
        $package = $this->db->fetch("SELECT * FROM packages WHERE id = ?", [(int) $id]);
        if (!$package) { redirect('/admin/paketler'); }
        $categories = $this->db->fetchAll("SELECT id, name FROM categories WHERE status = 'active' ORDER BY name");
        $fields = $this->db->fetchAll("SELECT * FROM package_fields WHERE package_id = ? ORDER BY sort_order", [(int) $id]);
        $seo = (new SeoScoreService())->calculate($package);

        $this->renderAdmin('admin/packages/form', [
            'pageTitle' => 'Paket Düzenle', 'package' => $package, 'categories' => $categories, 'fields' => $fields, 'seoResult' => $seo
        ]);
    }

    public function update(string $id): void
    {
        Csrf::check();
        $data = $this->getPackageData();
        if (!empty($_FILES['image']['name'])) { $data['image'] = Upload::image($_FILES['image'], 'packages'); }
        $data['seo_score'] = (new SeoScoreService())->calculate($data)['score'];

        $this->db->update('packages', $data, 'id = ?', [(int) $id]);
        logActivity('package_update', 'Paket güncellendi: ' . $data['name']);
        flash('success', 'Paket güncellendi.');
        redirect('/admin/paketler');
    }

    public function delete(string $id): void
    {
        Csrf::check();
        $this->db->delete('packages', 'id = ?', [(int) $id]);
        $this->db->delete('package_fields', 'package_id = ?', [(int) $id]);
        logActivity('package_delete', 'Paket silindi: ID ' . $id);
        flash('success', 'Paket silindi.');
        redirect('/admin/paketler');
    }

    public function toggleStatus(string $id): void
    {
        Csrf::check();
        $pkg = $this->db->fetch("SELECT status FROM packages WHERE id = ?", [(int) $id]);
        $this->db->update('packages', ['status' => $pkg['status'] === 'active' ? 'inactive' : 'active'], 'id = ?', [(int) $id]);
        flash('success', 'Durum güncellendi.');
        redirect('/admin/paketler');
    }

    public function fields(string $id): void
    {
        $package = $this->db->fetch("SELECT * FROM packages WHERE id = ?", [(int) $id]);
        if (!$package) { redirect('/admin/paketler'); }
        $fields = $this->db->fetchAll("SELECT * FROM package_fields WHERE package_id = ? ORDER BY sort_order", [(int) $id]);
        $this->renderAdmin('admin/packages/fields', ['pageTitle' => 'Paket Alanları: ' . $package['name'], 'package' => $package, 'fields' => $fields]);
    }

    public function saveFields(string $id): void
    {
        Csrf::check();
        $this->db->delete('package_fields', 'package_id = ?', [(int) $id]);
        $keys = $_POST['field_key'] ?? [];
        $labels = $_POST['field_label'] ?? [];
        $types = $_POST['field_type'] ?? [];
        $required = $_POST['field_required'] ?? [];
        $placeholders = $_POST['field_placeholder'] ?? [];

        foreach ($keys as $i => $key) {
            if (empty($key)) continue;
            $this->db->insert('package_fields', [
                'package_id' => (int) $id,
                'field_key' => $key,
                'field_label' => $labels[$i] ?? '',
                'field_type' => $types[$i] ?? 'text',
                'is_required' => isset($required[$i]) ? 1 : 0,
                'placeholder' => $placeholders[$i] ?? '',
                'sort_order' => $i,
            ]);
        }
        flash('success', 'Paket alanları kaydedildi.');
        redirect('/admin/paket/' . $id . '/alanlar');
    }

    private function getPackageData(): array
    {
        return [
            'category_id' => (int) ($_POST['category_id'] ?? 0),
            'name' => trim($_POST['name'] ?? ''),
            'slug' => trim($_POST['slug'] ?? '') ?: slugify($_POST['name'] ?? ''),
            'short_description' => trim($_POST['short_description'] ?? ''),
            'description' => $_POST['description'] ?? '',
            'image_alt' => trim($_POST['image_alt'] ?? ''),
            'price' => (float) ($_POST['price'] ?? 0),
            'discount_price' => !empty($_POST['discount_price']) ? (float) $_POST['discount_price'] : null,
            'delivery_time' => trim($_POST['delivery_time'] ?? ''),
            'min_quantity' => (int) ($_POST['min_quantity'] ?? 1),
            'max_quantity' => (int) ($_POST['max_quantity'] ?? 1),
            'badge' => trim($_POST['badge'] ?? '') ?: null,
            'status' => $_POST['status'] ?? 'active',
            'sort_order' => (int) ($_POST['sort_order'] ?? 0),
            'is_featured' => isset($_POST['is_featured']) ? 1 : 0,
            'seo_title' => trim($_POST['seo_title'] ?? ''),
            'seo_description' => trim($_POST['seo_description'] ?? ''),
            'seo_focus_keyword' => trim($_POST['seo_focus_keyword'] ?? ''),
            'canonical_url' => trim($_POST['canonical_url'] ?? ''),
            'og_title' => trim($_POST['og_title'] ?? ''),
            'og_description' => trim($_POST['og_description'] ?? ''),
        ];
    }
}
